# PROJECT_STATUS.md

Stand: 2026-09-19  
Aktueller Client-Entwicklungsstand: **v0.13.63**  
Aktuelle NAS-Codebasis: **v0.13.63**  
Projekt: HCA Manager / HCA Produktionsmanager

## v0.13.63 – Sendcloud-Absenderland zuverlässig übergeben

### Ursache und Korrektur
- Sendcloud lehnte die Preisabfrage mit `Field required` für `/from_address/country_code` ab.
- Die gespeicherte NAS-Compose-Datei enthält `SENDCLOUD_FROM_COUNTRY: "DE"` korrekt; eine Compose-Änderung ist daher nicht erforderlich.
- Der Server normalisiert den Absender-Ländercode unmittelbar beim Erstellen der Sendcloud-Adresse und erneut direkt vor der Preisabfrage.
- Leere, nur aus Leerzeichen bestehende oder nicht zweistellige Werte werden auf `DE` zurückgesetzt. Das Feld wird nicht mehr aus dem Payload entfernt.
- Dieselbe Normalisierung gilt für Empfängeradressen und für die vollständige Absenderadresse bei der Labelerstellung.
- Fehlende weitere Absender-Pflichtfelder werden vor dem externen API-Aufruf als verständliche HCA-Meldung ausgegeben.

### Auftragsweite Paketdaten für Einzelversand
- Im Versandbereich erscheint für jeden Produktionsauftrag mit offenen Einzelsendungen eine gemeinsame Paketvorlage.
- Gewicht, Länge, Breite und Höhe werden einmal erfasst und zentral auf alle noch nicht versendeten Einzelsendungen des Auftrags übertragen.
- Die Sendcloud-Preisabfrage wird einmal anhand der ersten offenen Empfängeradresse ausgeführt. Die ausgewählte Versandart, Vertrags-ID und der angezeigte Preis werden anschließend in allen offenen Sendungen gespeichert.
- Die gespeicherte Auftrags-Versandart wird im einzelnen Versanddialog vorausgewählt und beim automatischen Versand nach Fertigmeldung direkt verwendet; eine erneute Preisabfrage je Empfänger ist nicht erforderlich.
- Bereits versendete oder aktuell in Erstellung befindliche Sendungen bleiben unverändert.
- Die Oberfläche weist darauf hin, dass Sendcloud bei unterschiedlichen Zielländern oder adressabhängigen Zuschlägen tatsächlich abweichend abrechnen kann.

### Installation
- NAS: nur `app/hca_shared.py` ersetzen und den vorhandenen Container neu starten.
- `docker-compose.yml` bleibt unverändert; kein Image-Neubau erforderlich.
- Danach Clientupdate v0.13.63 installieren und HCA neu starten.

### Teststatus v0.13.63
- Python-Syntaxprüfung: bestanden.
- Absenderland fehlt, ist leer oder enthält nur Leerzeichen → `DE`: bestanden.
- Ungültiges ausgeschriebenes Empfängerland → zweistelliger Standardcode `DE`: bestanden.
- Abgefangener Sendcloud-v3-Preis-Payload enthält `/from_address/country_code = DE`: bestanden.
- Sammeltest mit zwei offenen und einer bereits versendeten Einzelsendung: Paketdaten und Versandart nur auf die beiden offenen Sendungen übernommen; bestanden.
- Auftragsstrategie `order_selected` und Wiederverwendung der gespeicherten Versandart beim automatischen Versand: bestanden.
- Bestehende Backend-, IMAP-, Neutralversand- und PDF-Regressionstests: bestanden.

## v0.13.62 – E-Mail-Arbeitsabläufe und Neutralversand

### Mailliste und Ordner
- Nachrichten lassen sich per Kontrollkästchen, Strg-Klick oder Umschalt-Klick mehrfach markieren; `Entf` löscht die Auswahl nach Bestätigung.
- Markierte Nachrichten können per Drag-and-drop innerhalb desselben Postfachs in andere Ordner verschoben werden.
- Das Rechtsklickmenü der Mailliste bietet Drucken, Antworten, Allen antworten, Weiterleiten, gelesen/ungelesen, Nachverfolgung, Junk → Absender sperren, Archivieren und Löschen.
- Das Rechtsklickmenü der Ordner bietet neuen Unterordner, Umbenennen und Löschen für benutzerdefinierte Ordner sowie das Leeren des gewählten Ordners.
- Zur Nachverfolgung markierte E-Mails werden zentral gespeichert und auf dem Dashboard angezeigt.
- Gesperrte Absender werden pro Postfach gespeichert; beim Laden eines Ordners werden neu erkannte Nachrichten dieser Absender in den Junk-Ordner verschoben.

### HTML-Mail und Signaturen
- Auch der allgemeine E-Mail-Editor kann die bestehende HTML-Firmenvorlage verwenden; die Funktion ist beim Verfassen standardmäßig aktiviert und abschaltbar.
- Persönliche Signaturen akzeptieren formatierten HTML-Inhalt, Tabellen und Bilder. Aus Outlook eingefügte Bilddaten werden übernommen und beim Versand als CID-Inline-Bilder eingebettet.
- Das bereits im System hinterlegte Firmenlogo kann direkt in die Signatur eingefügt werden.
- Die doppelte orange Dokumentbezeichnung über dem eigentlichen Titel wurde aus Rechnung, Angebot, Auftragsbestätigung und Lieferschein entfernt.
- Externe Bilder in empfangenen Mails bleiben weiterhin nach Absenderfreigabe sichtbar; diese bestehende Freigabe bleibt unverändert erhalten.

### Neutralversand und Versandbenachrichtigung
- Neue und bestehende Kundenaufträge können als `Neutraler Versand` markiert werden; die Einstellung wird bei Duplikaten und daraus erzeugten Lieferscheinen übernommen.
- Ein neutraler Lieferschein wird ohne Briefpapier, Firmenlogo und hervorgehobenen Firmennamen erzeugt.
- Die automatische HCA-Versandmail nach erfolgreichem Versand verwendet bei Neutralversand ein zurückhaltendes, ungebrandetes Layout.
- Versandetiketten benötigen weiterhin eine vollständige Zustelladresse. Auch bei neutralem Versand können transportrechtlich erforderliche Absenderdaten auf dem Carrier-/Sendcloud-Label stehen.
- Die bereits vorhandene HCA-Trackingmail bleibt der verlässliche Benachrichtigungsweg; eine zusätzliche Sendcloud-Mail wird nicht parallel erzwungen.

### Installation
- NAS: nur `app/hca_shared.py` ersetzen und den vorhandenen Container normal neu starten.
- `docker-compose.yml` bleibt unverändert; kein Image-Neubau erforderlich.
- Neue SQLite-Spalten und Tabellen werden beim Serverstart automatisch angelegt.
- Danach Desktop-Update v0.13.62 installieren und HCA vollständig neu starten.

### Teststatus v0.13.62
- Python-Syntaxprüfung der NAS-Erweiterung: bestanden.
- JavaScript-Syntaxprüfungen der geänderten Clientdateien: bestanden.
- SQLite-Migration, Neutralversand-Übernahme in Lieferscheine und Umschaltung bestehender Aufträge: bestanden.
- HTML-Mailrenderer, Bild-CID-Verarbeitung und Entfernung der doppelten Dokumentbezeichnung: bestanden.
- Neutraler Lieferschein als PDF erzeugt, mit Poppler gerendert und visuell auf Branding, Überlagerungen und abgeschnittene Inhalte geprüft: bestanden.
- IMAP-Ordner- und Bulkaktionen sind ohne Zugang zu einem produktiven Mailserver strukturell geprüft; der reale Provider-Test bleibt nach Installation erforderlich.

## v0.13.61 – Bündige Dokumentköpfe und Adressblöcke

### Umsetzung
- Bei Rechnung, Auftragsbestätigung und Lieferschein beginnt der Datumsblock jetzt an derselben horizontalen Position wie der jeweilige Dokumenttitel.
- Das Angebot verwendete diese Flucht bereits und bleibt dort unverändert.
- Die Empfängeranschrift beginnt bei Angebot, Auftragsbestätigung, Rechnung und Lieferschein jetzt bei x = 71 pt und damit bündig mit der Absenderzeile des Briefpapiers.
- Tabellen, Betreffzeilen, Summenblöcke und Seitenumbrüche wurden nicht verschoben.
- Die Firmenlogo-Korrektur aus v0.13.60 ist vollständig enthalten.

### Installation
- NAS: nur `app/hca_shared.py` ersetzen und den vorhandenen Container normal neu starten.
- `docker-compose.yml` bleibt unverändert; kein Image-Neubau erforderlich.
- Danach Desktop-Update v0.13.61 installieren und HCA vollständig neu starten.

### Teststatus v0.13.61
- PDF-Koordinatentest für Angebot, Auftragsbestätigung, Rechnung und Lieferschein: bestanden.
- Alle vier A4-Musterseiten mit Poppler gerendert und visuell auf Fluchten, Überlagerungen und abgeschnittene Inhalte geprüft: bestanden.
- Datumsblock jeweils bei x = 420 pt wie der Dokumenttitel: bestanden.
- Empfängeranschrift jeweils bei x = 71 pt wie die Absenderzeile: bestanden.
- Python- und JavaScript-Syntaxprüfungen sowie Paketintegrität: bestanden.

## v0.13.60 – Firmenlogo in HTML-Dokumentmails korrigiert

### Ursache und Korrektur
- v0.13.59 verwendete versehentlich das quadratische HCA-Anwendungsicon als Logo in ausgehenden Dokumentmails.
- Dieses Bild ist ausschließlich das Programmsymbol und nicht für die Kundenkommunikation bestimmt.
- Der Mailrenderer verwendet jetzt exakt das bereits im HCA-Client enthaltene Firmenlogo.
- Dieselbe PNG-Datei ist auch direkt in `app/hca_shared.py` eingebettet. Es wird weder das Anwendungsicon gelesen noch beim Empfänger ein externes Bild von der Webseite geladen.
- Das Firmenlogo bleibt als CID-Inline-Bild Bestandteil der Mail und erscheint nicht als normaler zusätzlicher Dateianhang.

### Unverändert
- HTML-Layout, eigene Vorlagentexte, Absenderpostfächer und Dokumentanhänge bleiben unverändert.
- Manueller Versand sowie die 19-Uhr-Rechnungsautomatik verwenden automatisch das korrigierte Firmenlogo.
- NAS-Installation weiterhin nur durch Austausch von `app/hca_shared.py`; keine Änderung an `docker-compose.yml` und kein Neubau.

### Teststatus v0.13.60
- Mail- und Clientlogo sind bytegenau identisch: bestanden.
- PNG-Signatur, Bildgröße 1500 × 320 Pixel und CID-MIME-Aufbau: bestanden.
- Kein Zugriff des Mailrenderers auf `logo-app.png` oder das eingebettete HCA-Anwendungsicon: bestanden.
- Python- und JavaScript-Syntaxprüfungen: bestanden.

## v0.13.59 – Gestaltete HTML-Mails für Geschäftsdokumente

### Umsetzung
- Rechnung, Angebot, Auftragsbestätigung und Lieferschein verwenden ein gemeinsames responsives HTML-Maildesign mit WSK-Farben, Dokumentkopf, übersichtlichen Belegdaten, Nachricht und Firmenfuß.
- Das fest eingebaute Werbestudio-Königswinter-Logo wird als CID-Inline-PNG in die E-Mail eingebettet. Der Empfänger muss dafür keine externen Bilder freigeben; das Logo erscheint nicht als zusätzlicher normaler Dateianhang.
- Die bestehenden Rechnungsvorlagen bleiben erhalten und werden automatisch im neuen Design ausgegeben. Für Angebote, Auftragsbestätigungen und Lieferscheine werden bei der Migration eigene Standard- und Kurzvorlagen ergänzt.
- Unter Einstellungen lassen sich die Vorlagen getrennt nach Dokumenttyp auswählen, ergänzen, bearbeiten, löschen und als Standard festlegen. Die Oberfläche zeigt jeweils nur die gültigen Platzhalter des ausgewählten Dokumenttyps.
- Alle vier Versanddialoge bieten Absenderpostfach, HTML-Vorlage, Empfänger, Betreff, editierbaren Nachrichtentext, Anhangsstatus und eine HTML-Vorschau.
- Angebote und Lieferscheine nutzen nicht mehr ihre alten fest verdrahteten Mailtexte. Aufträge erhalten erstmals den direkten Versand einer Auftragsbestätigung inklusive PDF.
- Beim Angebot wird der Status nach erfolgreichem Versand auf „gesendet“ gesetzt. Auftragsbestätigung und Lieferschein speichern Versandzeit, Empfänger und einen eventuellen Fehler.
- Der automatische Rechnungsversand um 19:00 Uhr verwendet dieselbe zentrale HTML-Ausgabe wie der manuelle Versand; ZUGFeRD-/XRechnungs-Anhangsregeln bleiben unverändert.

### Kompatibilität und Installation
- Bestehende eigene Rechnungstexte und SMTP-Postfächer werden nicht überschrieben.
- NAS-Patch: nur `app/hca_shared.py` ersetzen und den vorhandenen Container neu starten. `docker-compose.yml` bleibt unverändert; kein Image-Neubau ist erforderlich.
- Danach Desktop-Update v0.13.59 installieren und HCA vollständig neu starten.

### Teststatus v0.13.59
- Python-Syntaxprüfung und JavaScript-Syntaxprüfungen: bestanden.
- Frische SQLite-Migration: je eine Standardvorlage sowie weitere Varianten für alle vier Dokumenttypen vorhanden; bestanden.
- HTML-Renderer: CID-Logo in Versandmail und eingebettetes Data-URL-Logo in der Vorschau; bestanden.
- MIME-Test: HTML-Alternative, Inline-Logo mit Content-ID und PDF-Anhang werden korrekt zusammengesetzt; bestanden.
- Kontext-/Vorschautest für Angebot, Auftragsbestätigung und Lieferschein mit Empfänger, Belegnummer und PDF-Dateiname: bestanden.

## v0.13.58 – PDF-Erkennung für Einkauf und Lieferantenrechnungen

### Umsetzung
- Der Rechtsklick auf einen PDF-Mailanhang übergibt die Originaldatei weiterhin direkt an Lieferantenrechnung oder Onlinebestellung und startet nun zusätzlich die serverseitige Textauslesung.
- Lieferantenrechnungen werden mit Lieferant, Rechnungsnummer, Bestellreferenz, Rechnungs- und Fälligkeitsdatum, Netto, Steuer, Brutto und Steuersatz vorbefüllt.
- Das Lieferantenfeld ist durchsuchbar. Ein noch nicht vorhandener Lieferant kann direkt aus der Rechnungserfassung angelegt und anschließend automatisch ausgewählt werden.
- Bestellbestätigungen werden mit Lieferant, Bestellreferenz und Datum vorbefüllt. Positionen werden über Lieferanten-SKU, SKU, ERP-Code, Barcode oder Artikel-SKU mit dem HCA-Artikelstamm abgeglichen und mit erkannter Menge eingesetzt.
- Nicht eindeutig zuordenbare Bestellzeilen werden sichtbar zur Prüfung aufgeführt. Es wird keine unbekannte Position stillschweigend angelegt.
- PDFs ohne Textschicht bleiben sicher angehängt und erhalten einen klaren Hinweis zur manuellen Prüfung; OCR für reine Scans ist noch nicht enthalten.
- Das NAS-Update ist als kleine Patch-Datei vorgesehen: nur `app/hca_shared.py` austauschen und den bestehenden Container neu starten; `docker-compose.yml` bleibt unverändert.

### Teststatus v0.13.58
- Python-Syntaxprüfung: bestanden.
- JavaScript-Syntaxprüfung der geänderten Clientdateien: bestanden.
- Parser-Test für deutsche Rechnungsnummern, Datums- und Betragsformate sowie Lieferantenzuordnung: bestanden.
- Parser-Test für Bestellnummer, Bestelldatum, SKU-Zuordnung und Mengenübernahme: bestanden.
- PDF-Textwerkzeuge Ghostscript und `pdftotext` in der Buildbasis verfügbar.

### Installation
- Auf dem NAS nur die Datei `app/hca_shared.py` aus dem NAS-Patch in den vorhandenen HCA-Ordner kopieren und den laufenden Container neu starten. Keine Compose-Änderung und kein Neubau erforderlich, wenn v0.13.53 oder neuer installiert ist.
- Danach Desktop-Update v0.13.58 installieren und HCA vollständig neu starten.

## v0.13.57 – Automatischer Rechnungsversand und vollständige Mailanhänge

### Umsetzung
- Client und NAS liefern den Rechnungsversand wieder als gemeinsamen Stand aus; ein alter NAS-Stand wird im Dialog konkret benannt statt nur als `Not Found` angezeigt.
- Seit v0.13.57 festgeschriebene und noch nicht manuell versendete Rechnungen werden täglich um 19:00 Uhr Europe/Berlin automatisch gesendet. Altbelege werden nicht rückwirkend ungefragt verschickt.
- Manuell und automatisch wird ausschließlich die validierte ZUGFeRD-PDF beziehungsweise bei Leitweg-ID die validierte XRechnung angehängt.
- Automatik, Versandzeit, Absender und Vorlage sind in den Einstellungen wählbar; der letzte Lauf und sein Ergebnis werden angezeigt.
- Empfangene Mailanhänge besitzen Download, integrierte Vorschau und ein Rechtsklickmenü für die direkte Übergabe an Onlinebestellung oder Lieferantenrechnung.
- Externe Bilder werden nach einmaliger Freigabe für dieselbe Absenderadresse künftig automatisch angezeigt; eingebettete CID-Bilder werden direkt aus der Mail geladen.
- „Neue E-Mail an Kunden“ öffnet den Verfassen-Dialog direkt und übernimmt die Adresse, ohne die Kundenakte zu verlassen.

### Teststatus v0.13.57
- Python- und vollständige JavaScript-Syntaxprüfung: bestanden.
- Frische Datenbankmigration: bestanden.
- Simulierter automatischer ZUGFeRD-Versand mit Wiederholungsschutz: bestanden.
- Altbeleg ohne neue Versandvormerkung bleibt unberührt: bestanden.
- NAS- und Desktoparchive vollständig mit ZIP-Integritätsprüfung geprüft: bestanden.

### Installation
- NAS-Paket v0.13.57 kopieren und Container neu starten; bei einem Stand vor der Java/Ghostscript-Basis einmal mit `--build` neu bauen.
- Desktop-Update v0.13.57 installieren und HCA vollständig neu starten.
- Unter Einstellungen den automatischen Rechnungsversand prüfen; Standard ist täglich 19:00 Uhr Europe/Berlin.

## v0.13.54 – Direkter Rechnungsversand mit Textvorlagen

### Ausgangslage
- Die gemeldete E-Rechnungsansicht entsprach weiterhin v0.13.52: zwei manuelle XML-Karten und der Hinweis, ZUGFeRD/PDF-A-3 sei nicht freigegeben.
- Damit war der automatische v0.13.53-Client auf dem Arbeitsplatz noch nicht aktiv beziehungsweise wurde weiterhin aus dem Browsercache geladen.
- Ein direkter, rechnungsspezifischer E-Mail-Versand mit Vorlagenauswahl fehlte bislang.

### Umsetzung
- Der E-Rechnungsclient erhält erneut einen eindeutigen Cache-Schlüssel `v=0.13.54`; ein neues, zuletzt geladenes Versionsoverlay setzt den Clientstand sichtbar auf v0.13.54.
- Festgeschriebene Kundenrechnungen zeigen die Aktion „Per E-Mail senden“.
- Der Versanddialog lädt alle Postfächer mit Versandberechtigung und alle aktiven Rechnungsvorlagen.
- Empfängeradresse wird aus der Rechnungsadresse beziehungsweise dem Kundenstamm übernommen; Betreff und Nachricht werden aus der gewählten Vorlage befüllt und bleiben editierbar.
- Drei Standardvorlagen werden automatisch angelegt: Standard, mit Dank und Kurztext.
- Zentrale Vorlagenverwaltung unter Einstellungen mit Anlegen, Bearbeiten, Entfernen und Standardauswahl.
- Unterstützte Platzhalter: `{kundenname}`, `{rechnungsnummer}`, `{rechnungsdatum}`, `{faellig_am}`, `{betrag}`, `{firmenname}`.
- Der Versand hängt ohne Leitweg-ID ausschließlich das validierte ZUGFeRD-PDF und mit Leitweg-ID ausschließlich die KoSIT-validierte XRechnung-XML an.
- Fehlende oder nicht validierte E-Rechnungen blockieren den Versand mit einer konkreten Meldung.
- Versandzeitpunkt, Empfänger und verwendete Vorlage werden in der Rechnung gespeichert und beim nächsten Öffnen des Versanddialogs angezeigt.
- Die vorhandene Postfachsignatur wird beim Versand automatisch ergänzt.

### Teststatus v0.13.54
- Python- und JavaScript-Syntaxprüfungen: bestanden.
- Datenbankschema einschließlich Vorlagentabelle und Versandprotokoll-Spalten: bestanden.
- Drei Standardvorlagen werden einmalig und ohne Duplikate angelegt: bestanden.
- Platzhalterauflösung für Rechnungsnummer, Kunde, Datum, Fälligkeit und deutschen Bruttobetrag: bestanden.
- ZUGFeRD-Rechnung als `application/pdf` versendet; Anhang beginnt mit gültigem PDF-Header: bestanden.
- Leitweg-ID-Rechnung als `application/xml` versendet; Anhang enthält die KoSIT-validierte XRechnung: bestanden.
- Postfachsignatur wird ergänzt und Versandmetadaten werden an der Rechnung gespeichert: bestanden.
- Zentrale Vorlagenersetzung mit zwei eigenen Vorlagen und Standardauswahl: bestanden.
- Automatische ZUGFeRD-Validierung weiterhin PDF/A-Flavour `3u`; XRechnung weiterhin KoSIT `ACCEPTABLE`: bestanden.

### Installation
- NAS-Dateien kopieren und Container neu starten.
- Falls v0.13.53 noch nicht mit neu gebautem Container installiert wurde, einmal mit `--build` neu bauen.
- Desktop-Update v0.13.54 installieren und HCA vollständig beenden und neu starten.

## v0.13.53 – ZUGFeRD automatisch, XRechnung nach Leitweg-ID

### Umsetzung
- Kunden und Rechnungen besitzen jetzt ein eigenes Feld `leitweg_id`; der Kundenwert wird in neue Rechnungsentwürfe übernommen und kann belegspezifisch überschrieben werden.
- Ohne Leitweg-ID wählt HCA automatisch ZUGFeRD 2.5.2 / Factur-X 1.09.2 im Profil EN 16931.
- Mit Leitweg-ID wählt HCA automatisch XRechnung 3.0.2; BT-10 wird vorrangig mit der Leitweg-ID befüllt.
- Beim Festschreiben läuft die E-Rechnungs-Vorprüfung vor Vergabe der endgültigen Nummer. Fehlende Pflichtdaten oder Laufzeitbestandteile blockieren die Festschreibung mit einer konkreten Meldung.
- Die Sichtrechnung wird mit Ghostscript nach PDF/A-3 konvertiert, die EN-16931-CII mit Mustangproject eingebettet und das Gesamtdokument anschließend erneut geprüft.
- Ein ZUGFeRD-PDF wird nur veröffentlicht, wenn PDF und XML im Mustangproject-Prüfergebnis beide sowie insgesamt `valid` sind.
- Das validierte ZUGFeRD-PDF wird für PDF-Download, Druck und E-Mail-Anhang verwendet. Bei XRechnung wird im E-Mail-Dialog automatisch die KoSIT-validierte XML verwendet.
- Archivexporte enthalten zusätzlich `invoice-zugferd.pdf`; Manifest und Datenbank speichern Hash, Generator, Profil und externes Prüfergebnis.
- Docker installiert Ghostscript und bindet Mustangproject CLI 2.26.0 schreibgeschützt ein; die gebündelte JAR wird gegen die offizielle SHA-256-Prüfsumme geprüft.
- Die Oberfläche zeigt nur das automatisch ausgewählte Zielformat und dessen echten Prüfstatus. Manuelles Neuerzeugen und der passende Download bleiben verfügbar.

### Teststatus v0.13.53
- Python- und JavaScript-Syntaxprüfungen: bestanden.
- Frische Datenbank und automatische Migration der Leitweg-ID-Spalten: bestanden.
- Vollständiger Standardablauf Festschreiben → PDF/A-3 → XML-Einbettung → Mustangproject-Prüfung: bestanden; Gesamtstatus, PDF und XML jeweils `valid`, PDF/A-Flavour `3u`.
- Eingebettete Datei als `zugferd-invoice.xml` wieder extrahiert: bestanden.
- Erneutes Erzeugen über eine bereits schreibgeschützte Archivdatei: bestanden.
- Leitweg-ID-Ablauf Festschreiben → XRechnung 3.0.2 → KoSIT: bestanden; KoSIT `ACCEPTABLE`, Bericht `valid=true`.
- Automatische E-Mail-Anhänge: ohne Leitweg-ID ZUGFeRD-PDF, mit Leitweg-ID XRechnung-XML: bestanden.
- Gerenderte PDF/A-3-Sichtprüfung: bestanden; sichtbarer PDF-Inhalt bleibt erhalten.

### Installation
- NAS-Paket kopieren und den Container einmal mit `--build` neu bauen, damit Ghostscript verfügbar ist.
- Danach Desktop-Update v0.13.53 installieren und HCA vollständig neu starten.
- Mustangproject wird aus `./zugferd` nach `/opt/hca/zugferd` eingebunden; Java und KoSIT bleiben unverändert aus v0.13.50 erhalten.

## v0.13.52 – KoSIT-Client aktiviert und SQLite-Startfehler behoben

### Live-Befund nach v0.13.51
- Der NAS-Server nahm `POST .../einvoice/validate` erfolgreich an und startete den neuen Hintergrundauftrag.
- Im Containerprotokoll folgte jedoch keine einzige Abfrage des Endpunkts `.../einvoice/job-status`.
- Ursache war der unveränderte Browser-Cache-Schlüssel `hca-v01345.js?v=0.13.45`: Trotz installiertem v0.13.51-Update konnte Chromium die alte synchrone Clientdatei weiterverwenden.
- Die alte Clientlogik deutete die sofortige Startbestätigung ohne `validation`-Objekt fälschlich als fehlende Java-/KoSIT-Installation.
- Parallel eintreffende API-Anfragen führten außerdem mehrfach zu `sqlite3.OperationalError: trigger ... already exists` und sporadischen HTTP-500-Antworten.

### Korrektur
- Der geänderte E-Rechnungs-Client erhält im `index.html` den Cache-Schlüssel `v=0.13.52` und wird dadurch nach dem Update sicher neu geladen.
- Der Client wartet wieder über den vorhandenen Statusendpunkt auf `queued`, `running`, `completed` oder `failed`.
- Eine nicht vorhandene Validierungsantwort löst keine erfundene Installationsmeldung mehr aus.
- Bei wirklicher Nichtverfügbarkeit oder Ablehnung wird die konkrete Meldung des KoSIT-Ergebnisses angezeigt.
- Die gesamte SQLite-Schema-Initialisierung ist jetzt pro Serverprozess einmalig und durch einen Prozess-Lock serialisiert.
- Damit können parallele Verbindungen weder Migrationen noch dieselben SQLite-Trigger gleichzeitig ausführen beziehungsweise neu anlegen.
- NAS- und Clientversion sind auf v0.13.52 angehoben.

### Teststatus v0.13.52
- `python -m py_compile app/hca_shared.py`: bestanden.
- Vollständiger Syntaxcheck aller Client-JavaScript-Dateien mit `node --check`: bestanden.
- Cache-Schlüssel des E-Rechnungsclients ist exakt einmal auf `v=0.13.52` gesetzt: bestanden.
- Neues Versionsoverlay v0.13.52 ist exakt einmal und nach v0.13.51 eingebunden: bestanden.
- Alte pauschale Java-/KoSIT-Fehlermeldung ist aus der ungeprüften Antwortauswertung entfernt: bestanden.
- Gleichzeitiger Zugriff mit 96 Verbindungen und 24 Threads: alle Verbindungen erfolgreich, Schema genau einmal initialisiert, keine Triggerkollision: bestanden.
- Acht erwartete Betriebsmodus-Trigger nach dem parallelen Test vorhanden: bestanden.
- NAS- und Desktop-Archive mit `unzip -t` vollständig geprüft: bestanden.
- Geänderter Backendcode und beide betroffenen Clientdateien direkt aus den fertigen Archiven geprüft: bestanden.

### Installation
- v0.13.52 setzt die funktionsfähige Java-/KoSIT-Containerbasis aus v0.13.50 voraus.
- NAS-Dateien kopieren, Container neu starten, Desktop-Update installieren und HCA vollständig neu starten.
- Danach genügt bei der bereits erzeugten XRechnung ein Klick auf „KoSIT erneut prüfen“.

## v0.13.51 – E-Rechnung ohne Client-Timeout

### Live-Befund nach v0.13.50
- KoSIT war im NAS-Container korrekt betriebsbereit.
- Beim Erzeugen wurde die XML erfolgreich gespeichert, die offene HTTP-Verbindung brach jedoch während der anschließenden KoSIT-Prüfung mit `signal is aborted without reason` ab.
- Dadurch blieb in der Datenbank der Zwischenstand `not_run` erhalten, obwohl der ausgelagerte Java-Prozess gegebenenfalls noch einen Prüfbericht erzeugte.
- Die Oberfläche zeigte deshalb „XML erzeugt · KoSIT-Prüfung ausstehend“ und interpretierte den noch fehlenden Ergebnisdatensatz fälschlich als nicht verfügbare KoSIT-Laufzeit.

### Korrektur
- NAS- und Clientversion sind auf v0.13.51 angehoben.
- Eine getrennte, threadsichere Auftragsverwaltung für E-Rechnungserzeugung und KoSIT-Prüfung ist vorbereitet.
- Erzeugen und erneutes KoSIT-Prüfen starten jetzt jeweils einen serverseitigen Hintergrundauftrag und bestätigen den Start sofort.
- Der komplette blockierende Ablauf läuft in einem Worker-Thread; während des KoSIT-Laufs bleibt keine HTTP-Verbindung offen.
- Neuer Statusendpunkt liefert `queued`, `running`, `completed` oder `failed`.
- Je Rechnung kann nur ein E-Rechnungsauftrag gleichzeitig laufen; Doppelklicks starten keinen zweiten Validatorprozess.
- Die Datenbankverbindung wird vor dem Java-Lauf geschlossen und erst zum Speichern des Prüfergebnisses neu geöffnet.
- Das externe Prüfergebnis wird zusätzlich in `einvoice/manifest.json` aktualisiert.
- Der Client fragt den Auftragsstatus alle 1,2 Sekunden ab, toleriert kurze Netzwerkunterbrechungen und wartet höchstens fünf Minuten.
- Die Buttons zeigen währenddessen „Erzeugt und prüft …“ beziehungsweise „KoSIT prüft …“ und bleiben gegen Doppelklicks gesperrt.
- Bei vorhandener KoSIT-Laufzeit bezeichnet der Hinweis einen noch ausstehenden Prüflauf jetzt korrekt und behauptet nicht mehr, KoSIT sei im Container nicht verfügbar.
- Clientoverlay, `version.json` und Update-Metadaten sind auf v0.13.51 angehoben.

### Teststatus v0.13.51
- `python -m py_compile app/hca_shared.py`: bestanden.
- Vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- Simulierter langsamer E-Rechnungsauftrag: Startantwort nach 0,0001 Sekunden, Eventloop bleibt frei, Endstatus `completed`: bestanden.
- Paralleler zweiter Start derselben Rechnung verwendet dieselbe Job-ID und erzeugt keinen zweiten Auftrag: bestanden.
- Simulierter fachlicher Fehler erreicht den Client als Status `failed` einschließlich konkreter Pflichtfeldmeldung: bestanden.
- Erfolgreiches KoSIT-Ergebnis wird in `finance_invoices.einvoice_validation_json` und `einvoice/manifest.json` als validiert gespeichert: bestanden.
- Clientpolling auf den neuen Job-Status, Fünf-Minuten-Grenze, Netzwerkfehlertoleranz und Fortschrittstexte statisch geprüft: bestanden.
- `index.html`: keine doppelten IDs; v0.13.51 genau einmal und als letztes Overlay geladen: bestanden.
- NAS- und Desktop-Archive mit `unzip -t` geprüft: bestanden.
- Backend direkt aus dem entpackten NAS-Paket geladen und Hintergrundauftrag bis `completed` ausgeführt: bestanden.
- Sämtliche JavaScript-Dateien direkt aus dem entpackten Desktop-Update mit `node --check` geprüft: bestanden.

### Installation
- v0.13.51 setzt die funktionierende Java-/KoSIT-Containerbasis aus v0.13.50 voraus.
- Auf dem NAS genügt der Austausch von `app/hca_shared.py` mit anschließendem normalen Containerneustart; das Image muss nicht erneut gebaut werden.
- Die bereits vorhandene XRechnung kann über „KoSIT erneut prüfen“ validiert werden und muss nicht neu erzeugt werden.

## v0.13.50 – Java und KoSIT dauerhaft in den NAS-Container eingebunden

### Live-Befund nach v0.13.49
- Der v0.13.49-Code lief auf der Synology, meldete aber gleichzeitig fehlendes Java, fehlendes Validator-JAR und fehlende XRechnung-Konfiguration.
- Die tatsächliche `docker-compose.yml` verwendete direkt `python:3.12-slim` und band nur `app`, `requirements.txt`, `data` und `config` ein.
- Deshalb konnte der außerhalb von `app` ausgelieferte Ordner `validator` im Container nicht sichtbar sein; außerdem enthält das schlanke Python-Basisimage keine Java-Laufzeit.

### Korrektur
- Neues `Dockerfile` auf Basis von `python:3.12-slim-bookworm` installiert dauerhaft OpenJDK 17 JRE headless.
- `docker-compose.yml` baut daraus das feste Image `hca-produktionsserver:0.13.50`.
- Der offizielle Validator-Ordner wird schreibgeschützt nach `/opt/hca/validator` eingebunden. Dieser Pfad entspricht exakt der bereits implementierten automatischen HCA-Erkennung.
- `.dockerignore` beschränkt den Build-Kontext auf das Dockerfile; Daten, Konfiguration und Zugangsdaten werden nicht in das Container-Image kopiert.
- Vorhandene Volumes, Ports, Umgebungsvariablen und der bisherige Startbefehl bleiben erhalten.
- NAS- und Clientversion sind auf v0.13.50 angehoben.

### Teststatus v0.13.50
- `python -m py_compile app/hca_shared.py`: bestanden.
- Vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- `docker-compose.yml` als YAML geladen und die erwartete Build-Konfiguration sowie alle fünf Volumes geprüft: bestanden.
- Alle 23 vorhandenen Umgebungsvariablen der bereitgestellten Compose-Datei bleiben enthalten.
- Ursprüngliche Umgebungswerte, Startbefehl, Port, Arbeitsverzeichnis, Neustartregel und vier vorhandene Volumes maschinell mit der hochgeladenen Compose-Datei verglichen: unverändert.
- Offizielles Image `python:3.12-slim-bookworm` ist für mehrere Linux-Architekturen verfügbar; Debian Bookworm stellt `openjdk-17-jre-headless` unter anderem für amd64, arm64 und armhf bereit.
- HCA-Laufzeit erkennt im Zielpfad Java, Validator-JAR und `scenarios.xml`; JAR-Prüfsumme korrekt: bestanden.
- XRechnung-CII mit dem v0.13.50-HCA-Generator erzeugt und mit dem echten KoSIT-Prozess geprüft: `validated=true`, Rückgabecode 0, Prüfbericht `valid=true`: bestanden.
- NAS- und Desktop-Archive mit `unzip -t` geprüft: bestanden; keine Python-Cachedateien enthalten.
- Personalisiertes NAS-Paket in ein leeres Verzeichnis entpackt: Dockerfile, `.dockerignore`, Compose-Datei, Backend, Validator-JAR und `scenarios.xml` vollständig vorhanden.
- HCA direkt aus dem entpackten NAS-Paket geladen: Version 0.13.50, gebündelte Laufzeit erkannt, JAR-Integrität bestätigt.
- Ein vollständiger Docker-Build war in der Arbeitsumgebung mangels Docker-Dienst nicht möglich und muss beim ersten Neuaufbau auf der Synology erfolgen.

## v0.13.49 – KoSIT-Prüfung wird mit HCA ausgeliefert

### Ziel und Umsetzungsstand
- HCA erhält den offiziellen KoSIT Validator 1.6.3 und die XRechnung-Konfiguration 2026-08-31 als Bestandteil der NAS-Erweiterung.
- Die NAS-Codebasis ist auf v0.13.49 angehoben.
- HCA bevorzugt weiterhin ausdrücklich konfigurierte Validator-Dateien unter `/data`, findet ersatzweise aber automatisch die neue gebündelte Version.
- Die SHA-256-Prüfsumme des gebündelten Validator-JARs wird geprüft; eine manipulierte oder beschädigte Datei wird nicht ausgeführt.
- Jeder Lauf erhält ein eigenes Berichtverzeichnis. Ein Erfolg wird nur gespeichert, wenn sowohl der KoSIT-Prozess erfolgreich endet als auch der offizielle XML-Prüfbericht `valid="true"` meldet.
- Fehlende Komponenten und uneindeutige Validatorfehler werden getrennt von einer fachlich abgelehnten XRechnung ausgewiesen.
- Desktop-Client, Versionsdatei und Update-Metadaten sind auf v0.13.49 angehoben; das neue Versionsoverlay wird zuletzt geladen.
- Der E-Rechnungsbereich zeigt bei erfolgreicher Erkennung „KoSIT integriert und betriebsbereit“. Falls nur die Java-Laufzeit fehlt, wird genau diese fehlende Voraussetzung benannt.
- NAS-Erweiterung und Desktop-Update sind gebaut und abschließend geprüft.
- ZUGFeRD bleibt das gewünschte Standardformat; die echte PDF/A-3-Erzeugung ist ein eigener, noch nicht freigegebener Folgeschritt.

### Zwischenprüfungen v0.13.49
- `python -m py_compile app/hca_shared.py`: bestanden.
- Gebündeltes JAR gegen die fest hinterlegte SHA-256-Prüfsumme geprüft: bestanden.
- Laufzeiterkennung findet Java, JAR und `scenarios.xml` automatisch und meldet `bundled=true`: bestanden.
- Bewusst ungültige XML mit dem echten KoSIT-Prozess geprüft: Rückgabecode 1, Prüfbericht `valid="false"`, HCA-Status `rejected`: bestanden.
- XRechnung-CII mit dem echten HCA-Generator aus einer vollständigen Testrechnung erzeugt und mit dem gebündelten KoSIT-Validator geprüft: Schema `Y`, Schematron `Y`, `ACCEPTABLE`, Prüfbericht `valid="true"`, HCA-Status `validated`: bestanden.
- Vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- `index.html`: keine doppelten IDs, keine literalen `\\n`-Sequenzen; v0.13.49 genau einmal und nach v0.13.48 geladen: bestanden.
- Versionskonsistenz von NAS-Code, Clientoverlay, `version.json` und Update-Metadaten: bestanden.
- Beide ausgelieferten Archive mit `unzip -t` geprüft: bestanden.
- NAS-Paket in ein leeres Verzeichnis entpackt und die darin enthaltene Laufzeit getestet: Version 0.13.49, gebündelter Validator erkannt, Prüfsumme gültig, ungültige XML korrekt abgelehnt: bestanden.

### Auslieferung und Voraussetzung
- Installations- und Änderungshinweise nennen den zwingend mitzukopierenden Ordner `validator`.
- Herkunft, Versionen und SHA-256-Prüfsummen der offiziellen KoSIT-Komponenten sind im Paket dokumentiert.
- Der Validator und die Regeln sind plattformneutral gebündelt. Java wird nicht architekturspezifisch in das Paket kopiert; im Container ist Java 11 oder neuer erforderlich.

## v0.13.48 – Verbleibende SQLite-Sperre in der PDF-Fußzeile behoben

### Live-Befund
- Der asynchrone Ablauf aus v0.13.47 funktionierte und lieferte erstmals den tatsächlichen Serverfehler zurück: `database is locked`.
- Die Sperre entstand innerhalb der Rechnungsarchivierung, nicht durch den Status-Polling-Endpunkt.

### Ursache
- `_invoice_archive_final()` arbeitete korrekt mit der bereits laufenden Festschreib-Transaktion und hatte das Dokumentprofil bereits über diese Verbindung geladen.
- Beim Erzeugen des Rechnungs-PDFs rief `_letterhead_footer_commands()` jedoch erneut `_document_settings()` auf.
- `_document_settings()` öffnete über `_db()` eine zweite SQLite-Verbindung. Deren Schema-/Einstellungszugriff kollidierte mit der bereits schreibenden Festschreib-Transaktion und löste `database is locked` aus.

### Korrektur
- Das bereits geladene Dokumentprofil wird jetzt explizit durch die komplette PDF-Kette gereicht:
  - `_invoice_archive_final()`
  - `_commercial_pdf_bytes()`
  - `_letterhead_pdf()` beziehungsweise `_hca137_quote_pdf()`
  - `_letterhead_footer_commands()`
- Beim Festschreiben und Archivieren öffnet die PDF-Fußzeile deshalb keine zweite Datenbankverbindung mehr.
- Normale PDF-Aufrufe außerhalb einer vorhandenen Transaktion bleiben kompatibel und können das Dokumentprofil weiterhin selbst laden.
- Der asynchrone Start-/Statusablauf aus v0.13.47 bleibt unverändert erhalten.

### Teststatus v0.13.48
- `python -m py_compile app/hca_shared.py`: bestanden.
- vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- PDF-Fußzeile mit explizit übergebenem Dokumentprofil getestet; `_document_settings()` wird dabei nachweislich nicht aufgerufen: bestanden.
- Archiv-Aufruf übergibt nachweislich `snapshot["seller"]` an die PDF-Erzeugung: bestanden.
- Signaturen und bestehende PDF-Aufrufer bleiben durch optionale Parameter rückwärtskompatibel: bestanden.
- ZIP-/Updateintegrität und Versionskonsistenz: bestanden.
- Physischer Synology-Test mit dem vorhandenen Rechnungsentwurf steht nach Installation aus.

## v0.13.47 – Asynchrone Rechnungsfestschreibung ohne offene Langzeitverbindung

### Anlass / Live-Befund
- Nach Installation von v0.13.46 brach der Festschreib-Aufruf im realen Betrieb weiterhin mit `Failed to fetch` ab.
- Damit war klar: Nicht mehr der 12-Sekunden-Abbruch des Clients, sondern die über die gesamte PDF-/Archiverzeugung offen gehaltene HTTP-Verbindung war der verbleibende Schwachpunkt. Browser, Reverse-Proxy oder Server konnten diese Verbindung trennen, ohne eine auswertbare HTTP-Fehlermeldung an HCA zurückzugeben.

### Neuer Ablauf
- `POST /finance/invoices/{id}/finalize` startet die Festschreibung nur noch und bestätigt den Start sofort mit einer Job-ID.
- Die atomare Festschreibung läuft unabhängig von dieser HTTP-Verbindung in einem Hintergrundtask und weiterhin in einem Worker-Thread.
- `GET /finance/invoices/{id}/finalize-status` liefert `queued`, `running`, `completed` oder `failed`.
- Der Client fragt den Status alle 1,2 Sekunden ab und wartet maximal drei Minuten.
- Kurze Netzwerkunterbrechungen während der Statusabfrage werden toleriert; fachliche Serverfehler werden dagegen sofort angezeigt.
- Der Button zeigt währenddessen **„Wird festgeschrieben …“** und ist gegen Doppelklicks gesperrt.

### Sicherheit und Wiederholungen
- Je Rechnung kann serverseitig nur ein Festschreibauftrag gleichzeitig laufen.
- Wiederholte Startaufrufe während eines laufenden Jobs liefern denselben laufenden Status und erzeugen keine zweite parallele Festschreibung.
- Endgültige Rechnungsnummer, Statuswechsel, Archiv-JSON, Rechnungs-PDF, SHA-256 und Archivdatenbankfelder bleiben weiterhin eine gemeinsame SQLite-Transaktion.
- Nach einem Serverneustart kann der Status-Endpunkt anhand des gespeicherten Rechnungsstatus erkennen, ob die Rechnung bereits festgeschrieben wurde.

### Teststatus v0.13.47
- `python -m py_compile app/hca_shared.py`: bestanden.
- vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- simulierter Langläufer: Startantwort kommt sofort, Eventloop bleibt ansprechbar, Status wechselt von `queued/running` auf `completed`: bestanden.
- paralleler zweiter Start derselben Rechnung erzeugt keinen zweiten Job: bestanden.
- Clientpolling, Fehlerauswertung und Versions-Ladereihenfolge statisch geprüft: bestanden.
- ZIP-/Updateintegrität und enthaltene Dateiprüfsummen: bestanden.
- Physischer Synology-Test mit der vorhandenen Testrechnung steht nach Installation aus.

## v0.13.46 – Rechnungen zuverlässig festschreiben

### Behobener Fehler
- Das Speichern eines Rechnungsentwurfs funktionierte, beim anschließenden Festschreiben brach der Client jedoch nach dem allgemeinen Standardtimeout von 12 Sekunden mit `signal is aborted without reason` ab.
- Betroffene Rechnungen blieben als Entwurf erhalten und konnten nach dem Aktualisieren erneut geöffnet werden.

### Client
- Beide Festschreibwege verwenden jetzt gezielt einen Timeout von **90 Sekunden**:
  - Festschreiben aus dem Rechnungsdetail.
  - Speichern und direktes Festschreiben aus dem Rechnungsformular.
- Bei einer tatsächlichen Zeitüberschreitung erscheint eine verständliche Meldung mit der ausdrücklichen Anweisung, zuerst die Rechnungsliste zu aktualisieren und den Status zu prüfen. Dadurch wird ein versehentliches mehrfaches Festschreiben vermieden.
- Normale API-Aufrufe behalten ihren bisherigen 12-Sekunden-Standardtimeout.

### NAS-Server
- Die blockierende PDF- und Archiverzeugung läuft nicht mehr direkt im FastAPI-Eventloop, sondern vollständig über `asyncio.to_thread`.
- Der Worker verwendet eine eigene SQLite-Verbindung im selben Thread.
- Die fachliche Transaktionsgrenze bleibt unverändert sicher: endgültige `RE-...`-Nummer, Statuswechsel, Archiv-JSON, Rechnungs-PDF, SHA-256 und Archivdatenbankfelder werden weiterhin nur gemeinsam festgeschrieben.
- Schlägt Pflichtprüfung oder Archiverzeugung fehl, wird die Datenbanktransaktion zurückgerollt und die Rechnung bleibt Entwurf.

### Bestandsschutz
- Der E-Rechnungs-Kern aus v0.13.45 wurde nicht fachlich verändert.
- `main.py` wurde nicht verändert.
- Bestehende Entwürfe können nach Installation weiterverwendet werden; die bereits angelegte Testrechnung muss nicht neu erstellt werden.

### Teststatus v0.13.46
- `python -m py_compile app/hca_shared.py`: bestanden.
- vollständiger Syntaxcheck aller Client-JavaScript-Dateien: bestanden.
- Versionskonsistenz von Client, Update-Metadaten und NAS-Status: bestanden.
- Festschreib-Endpunkt delegiert die synchrone Transaktion nachweislich an `asyncio.to_thread`.
- Beide Client-Festschreibwege verwenden nachweislich `timeoutMs:90000`.
- ZIP-/Updateintegrität und enthaltene Dateiprüfsummen: bestanden.
- Physischer Lauf auf der Synology mit der vorhandenen Testrechnung steht nach Installation noch aus.

## v0.13.45 – E-Rechnungs-Kern (EN 16931 / XRechnung) und stabile Versionsanzeige

### Versionsanzeige repariert
- Ursache des Springens zwischen alten Versionsständen gefunden: `version.json` stand in v0.13.44 noch auf 0.13.43, mehrere historische Overlays setzten `#appVersion` und `/api/status` konnte die Clientanzeige zusätzlich mit der NAS-/Serverversion überschreiben.
- `version.json`, Startanzeige und Update-Metadaten stehen jetzt konsistent auf **0.13.45**.
- `window.HCA_CLIENT_VERSION` ist die führende Clientversion. Historische Overlays und `/api/status` dürfen diese Anzeige nicht mehr herunterstufen.
- v0.13.45 wird als letztes Overlay geladen; ein MutationObserver hält die sichtbare Versionsanzeige stabil auf `v0.13.45`.

### SQLite-Sperre beim Rechnungs-Festschreiben behoben
- v0.13.44 konnte beim Festschreiben/Archivieren eine zweite SQLite-Verbindung für das Dokumentprofil öffnen, während die erste Verbindung bereits eine Schreibtransaktion hielt.
- Das Dokumentprofil wird für Compliance/Archiv/E-Rechnung jetzt über dieselbe vorhandene DB-Verbindung gelesen.
- Damit bleibt die Archivierung innerhalb der laufenden Transaktion ohne verschachtelte DB-Sperre.

### E-Rechnungsmodell
- Server erzeugt jetzt strukturiertes UN/CEFACT-CII-XML aus demselben festgeschriebenen HCA-Rechnungsdatensatz, aus dem auch Archiv/PDF stammen.
- Zwei Profile sind vorbereitet:
  - **EN 16931 CII** (`urn:cen.eu:en16931:2017`)
  - **XRechnung 3.0.2 CII** (`urn:cen.eu:en16931:2017#compliant#urn:xeinkauf.de:kosit:xrechnung_3.0`)
- XRechnung verwendet zusätzlich den Business-Process-Identifier `urn:fdc:peppol.eu:2017:poacc:billing:01:1.0`.
- Rechnungsnummer, Rechnungsdatum, Leistungsdatum, Fälligkeit, Verkäufer/Käufer, elektronische Adressen, Positionen, Mengen, UNECE-Einheiten, Netto-/Steuersummen, Umsatzsteuergruppen, Zahlungsbedingungen und SEPA-Zahlungsdaten werden strukturiert abgebildet.

### Strikte Vorprüfung
E-Rechnung wird nur erzeugt, wenn die für den aktuell sicheren Scope erforderlichen Daten vorliegen. Geprüft werden insbesondere:
- festgeschriebene Kundenrechnung und endgültige Rechnungsnummer
- gültiges Rechnungs-, Leistungs- und Fälligkeitsdatum
- Währung EUR
- vollständige Ausstelleranschrift, USt-IdNr., E-Mail, Telefon, IBAN
- vollständige Käuferanschrift
- für XRechnung: Käuferreferenz BT-10 und elektronische Käuferadresse
- mindestens eine Position, positive Menge, bekannte UNECE-Einheit
- derzeit bewusst nur 7 % oder 19 % USt.

0 %, steuerfreie Umsätze, Reverse Charge und sonstige Sondersteuersachverhalte werden **nicht automatisch geraten**, sondern in v0.13.45 blockiert, bis eine explizite Steuergrund-/Kategorie-Logik implementiert ist.

### E-Rechnungsarchiv und Export
- Erzeugte XML-Dateien werden unverändert unter dem bestehenden Rechnungsarchiv in `einvoice/` gespeichert.
- Jede XML erhält SHA-256; `einvoice/manifest.json` dokumentiert Profil, Erzeugungszeit, Hash und Validierungsstatus.
- Bereits festgeschriebene `invoice.pdf`, `invoice.json` und deren ursprünglicher Archivhash werden nicht überschrieben.
- Der herstellerneutrale Archiv-Export nimmt vorhandene E-Rechnungs-XMLs und Validierungsberichte zusätzlich mit auf.
- Damit bleibt HCA unabhängig von Lexware Office; Lexware ist weiterhin optionaler Connector und nicht die alleinige Daten-/Archivquelle.

### KoSIT-Validierung
- HCA besitzt jetzt eine lokale Validator-Schnittstelle für XRechnung.
- Automatische Erkennung unter `/data/hca_einvoice_validator` oder über `HCA_KOSIT_VALIDATOR_JAR` / `HCA_XRECHNUNG_SCENARIOS`.
- Unterstützt ist der offizielle KoSIT-CLI-Ablauf mit Java und `scenarios.xml`.
- Die Validierung läuft über `asyncio.to_thread`, damit der FastAPI-Eventloop nicht blockiert.
- **Nur** wenn der reale KoSIT-Prozess mit Erfolg zurückkehrt, setzt HCA den Status `validated` und zeigt „KoSIT-validiert“.
- Ist Java/KoSIT/Validator-Konfiguration nicht installiert, bleibt die XML bewusst `generated_unvalidated`.
- Empfohlener Stand zum 18.09.2026: KoSIT Validator **1.6.3** plus XRechnung-Konfiguration **2026-08-31** für XRechnung 3.0/3.0.2.

### ZUGFeRD bewusst noch nicht vorgetäuscht
- v0.13.45 erzeugt **noch kein** als ZUGFeRD bezeichnetes Hybrid-PDF.
- Ein normales PDF mit XML-Anhang wird nicht als ZUGFeRD ausgegeben.
- Für ZUGFeRD wird in einem nächsten Schritt eine echte PDF/A-3-Erzeugung samt passender Metadaten, Dateieinbettung und Validierung benötigt.
- Das jetzt erzeugte EN-16931-CII ist die strukturierte Datengrundlage dafür.

### Neue Serverrouten
- `GET /api/hca-shared/finance/invoices/{id}/einvoice/status`
- `POST /api/hca-shared/finance/invoices/{id}/einvoice/generate?format=xrechnung`
- `POST /api/hca-shared/finance/invoices/{id}/einvoice/generate?format=en16931`
- `GET /api/hca-shared/finance/invoices/{id}/einvoice/xml?format=...`
- `POST /api/hca-shared/finance/invoices/{id}/einvoice/validate?format=xrechnung`

### Client
- Rechnungsdetail enthält einen eigenen Bereich **E-Rechnung**.
- Getrennte Statuskarten für XRechnung und EN 16931.
- Erzeugen, herunterladen und XRechnung erneut mit KoSIT prüfen.
- Fehlende Pflichtdaten werden vor Erzeugung konkret angezeigt.
- ZUGFeRD wird ausdrücklich als noch nicht freigegeben angezeigt, statt einen falschen Konformitätsstatus zu suggerieren.

### Bestandsschutz
- `main.py` wurde **nicht** verändert.
- E-Mail v0.13.43, PC-Barcodescanner v0.13.40, mobiler Scanner, Test-/Produktionsbetrieb, Merch, Einkauf, Lager und Produktion bleiben kumulativ enthalten.
- Blocking I/O-Regel bleibt erhalten; KoSIT-Prozess läuft nicht im Eventloop.

### Teststatus v0.13.45
- `python -m py_compile app/hca_shared.py`: bestanden.
- vollständiger JS-Syntaxcheck aller 28 Client-JavaScript-Dateien einschließlich `app.js` und `hca-v01345.js`: bestanden.
- `index.html`: keine doppelten IDs, 0 literale `\n`-Sequenzen; v0.13.45-JS/CSS jeweils exakt einmal und als letztes Overlay eingebunden: bestanden.
- DB-Migration der neuen E-Rechnungsfelder in leerer Testdatenbank: bestanden.
- EN-16931-CII und XRechnung-CII aus einer Testrechnung erzeugt, UTF-8-XML erneut geparst und Kernfelder/Profil-IDs geprüft: bestanden.
- Vorprüfung blockiert fehlendes BT-10 und 0-%-Steuerfall: bestanden.
- Archiv-/Festschreibetest mit laufender SQLite-Schreibtransaktion: keine verschachtelte DB-Sperre mehr; bestanden.
- Paket-/ZIP-Integrität und Versionskonsistenz des v0.13.45-Desktop-/NAS-Builds: bestanden.
- **Keine Behauptung einer offiziellen XRechnung-Konformität ohne echten KoSIT-Lauf.** Die offizielle Validator-Laufzeit ist in diesem Update nicht binär gebündelt, weil die Java-Laufzeit des bestehenden NAS-Containers nicht vorausgesetzt werden darf.

## v0.13.44 – Rechnungs-Compliance-Grundlage und offenes Archiv

- Rechtliche Bestandsprüfung der HCA-Kundenrechnung gegen § 14 UStG durchgeführt.
- Liefer-/Leistungsdatum ergänzt und beim Festschreiben verpflichtend geprüft.
- PDF weist Umsatzsteuer nun je Steuersatz aus.
- Pflichtangaben-/Plausibilitätsprüfung vor Festschreibung ergänzt.
- Festgeschriebene Rechnungen werden als PDF + kanonischer JSON-Datensatz + SHA-256 archiviert.
- `retention_until` wird nach § 14b UStG grundsätzlich auf Ende des achten Folgejahres gesetzt; gesetzliche Verlängerungen bleiben vorbehalten.
- Herstellerneutraler Archivexport als ZIP ergänzt; Lexware Office bleibt optionale Schnittstelle und ist nicht führende Datenquelle.
- E-Rechnung wird noch nicht fälschlich behauptet: ZUGFeRD/XRechnung folgt erst mit EN-16931-Generator und Validator.
- `main.py` unverändert; E-Mail v0.13.43, Scanner, Lager, Merch, Einkauf und Produktion unverändert.

### Teststatus v0.13.44
- Python-Kompilierung bestanden.
- DB-Migration der neuen Rechnungsfelder in leerer Testdatenbank bestanden.
- JavaScript-Syntaxcheck für app.js und v0.13.44 bestanden.
- Paket-/ZIP-Integrität wird beim Build geprüft.
- Kein Live-Test mit Finanzamt, Lexware oder echtem EN-16931-Validator; v0.13.44 ist ausdrücklich noch keine E-Rechnungsfreigabe.

## v0.13.43 – IMAP-Umlaute, echte Ordnerhierarchie und HTML-Maildarstellung

### Anlass
Nach dem Live-Test von v0.13.42 wurden drei konkrete Punkte gemeldet: IMAP-Ordner mit Umlauten wurden falsch dargestellt, die Serverhierarchie wurde nur eingerückt statt als echter ein-/ausklappbarer Baum umgesetzt und HTML-Mails erschienen weiterhin als Text.

### IMAP-Ordnernamen / Umlaute
- Der Server dekodiert klassische IMAP-Ordnernamen jetzt nach **RFC 3501 Modified UTF-7**.
- Damit werden z. B. `Entw&APw-rfe` → **Entwürfe**, `Pr&APw-fungen` → **Prüfungen** und entsprechende ä/ö/ü/ß-Namen korrekt dargestellt.
- Für die eigentliche IMAP-Auswahl bleibt parallel der unveränderte Server-/Wire-Name erhalten; angezeigt wird nur der dekodierte Name. Dadurch werden Unicode-Anzeige und IMAP-SELECT nicht miteinander vermischt.

### Echte Ordnerhierarchie
- Die Ordner-API liefert jetzt `parent`, `parent_display`, `depth`, `selectable` und `has_children`.
- `\Noselect`-Ordner werden nicht mehr komplett verworfen. Sie erscheinen als reine Strukturknoten, damit darunterliegende Unterordner ihre echte Position behalten.
- Der Client baut daraus einen verschachtelten Baum statt einer flachen Liste mit Einrückung.
- Jeder Ordner mit Unterordnern besitzt einen eigenen Pfeil zum Ein-/Ausklappen.
- Der Zustand wird lokal gespeichert und bleibt nach einem Neustart erhalten.
- Die bereits vorhandene Möglichkeit, ganze Postfächer einzuklappen, bleibt zusätzlich bestehen.

### HTML-Mails
- `_mail_extract_body()` liefert jetzt neben dem Textkörper auch den originalen `text/html`-Teil an den Client.
- Enthält eine Nachricht HTML, wird dieser Teil im Lesebereich formatiert dargestellt. Nur wenn kein HTML vorhanden ist, wird auf den bisherigen Textkörper zurückgefallen.
- Vor der Darstellung wird HTML clientseitig gefiltert. Scripts, Stylesheets, Formulare, iFrames/Objekte, eingebettete aktive Inhalte und Event-Handler werden entfernt.
- Sichere typische Mailformatierung wie Tabellen, Absätze, Überschriften, Listen, Inline-Farben/Schriften und Links bleibt erhalten.
- Externe Bilder werden aus Datenschutz-/Sicherheitsgründen nicht automatisch nachgeladen. Im Lesebereich erscheint dafür **„Bilder laden“**; erst nach bewusstem Klick werden die externen Bild-URLs geladen. Data-/CID-Bilder werden direkt zugelassen, soweit der Browser sie auflösen kann.

### Client-Ladereihenfolge
- v0.13.43 enthält die komplette v0.13.42-Mailansicht plus die neuen Korrekturen.
- `hca-v01342.js/css` bleiben als historische Dateien im Updatepaket erhalten, werden in `index.html` aber nicht zusätzlich geladen. Dadurch laufen nicht zwei konkurrierende Mail-Renderer gleichzeitig.
- v0.13.41 bleibt darunter als bestehende Mail-/Rechtebasis geladen.

### Bestandsschutz
- `main.py` wurde **nicht** verändert.
- Lager, PC-Barcodescanner, mobiler Scanner, Einkauf, Merch, Produktion und Test-/Produktionsbetrieb wurden nicht verändert.
- Postfachkonten, Benutzerrechte und Zugangsdaten bleiben unverändert gespeichert.

### Teststatus v0.13.43
- `python -m py_compile app/hca_shared.py`: bestanden.
- Modified-UTF-7-Roundtrip-Test mit **Entwürfe**, **Gelöscht**, **Prüfungen**, **Müller & Söhne**: bestanden.
- Simulierter IMAP-LIST-Test mit `\Noselect`-Elternordner, zwei Hierarchieebenen und Umlauten: bestanden.
- HTML-Multipart-Test: Text- und HTML-Teil werden getrennt extrahiert; bestanden.
- `node --check` für v0.13.43 und vollständiger Client-JS-Check beim Paketbau: bestanden.
- Physischer Live-Test mit dem echten IMAP-Server und realen HTML-Mails steht nach Installation noch aus.

## v0.13.42 – E-Mail-Arbeitsbereich über volle Breite, gemeinsamer Posteingang und Systemanhänge

### Anlass / bestätigter Ist-Zustand
Nach dem ersten Live-Einsatz von v0.13.41 war die neue Mailansicht grundsätzlich nutzbar, aber auf einem großen Monitor blieb rechts und durch die zentrierte View auch links ungenutzte graue Fläche. Außerdem wurden IMAP-Unterordner unterhalb eines Archivpfades wegen der bisherigen Ordnerklassifikation fälschlich alle mit dem sichtbaren Namen **„Archiv“** dargestellt.

### Vollbreite-Mailcenter
- `#view-mail` hebt die allgemeine Maximalbreite ausschließlich für den E-Mail-Bereich auf.
- Die Mailansicht nutzt die komplette verfügbare Arbeitsbreite zwischen HCA-Seitenleiste und rechtem Fensterrand.
- Dreiteilung bleibt Outlook-artig: Postfächer/Ordner links, Nachrichtenliste in der Mitte, Lesebereich rechts.
- Die Lesebereich-Werkzeugleiste bleibt direkt oberhalb des Lesebereichs.
- Andere HCA-Ansichten behalten ihre bisherigen Breiten; es wurde keine globale Layoutregel verändert.

### Gemeinsamer und eigener Posteingang
- Oberhalb der Postfachliste gibt es **„Alle Posteingänge“**.
- Dieser lädt parallel die Posteingänge aller für den angemeldeten Benutzer lesbaren Konten, führt die Nachrichten zusammen und sortiert sie nach Datum.
- Jede Nachricht im gemeinsamen Posteingang zeigt zusätzlich, aus welchem Postfach sie stammt.
- Antworten und Löschen verwenden auch aus dem gemeinsamen Posteingang immer das konkrete Ursprungs-Postfach.
- Jedes Postfach besitzt weiterhin seinen eigenen **Posteingang** und seine serverseitigen IMAP-Ordner.
- Postfächer können per Pfeil in der linken Seitenleiste ein-/ausgeklappt werden; der Zustand wird lokal im Client gespeichert.

### IMAP-Ordnernamen repariert
Die Ursache der mehrfachen Anzeige **„Archiv“** lag in `_imap_parse_list_line`: Name/gesamter Pfad und IMAP-SPECIAL-USE-Klassifikation wurden gemeinsam ausgewertet und für Archive pauschal in das Label `Archiv` umgeschrieben.

Ab v0.13.42:
- Spezialrollen (`Sent`, `Drafts`, `Trash`, `Junk`, `Archive`) bestimmen nur noch Rolle/Icon.
- Der tatsächliche Name eines Unterordners bleibt sichtbar.
- Bei hierarchischen Namen wird der eigene Ordnername (letztes Segment) angezeigt.
- Nur der echte generische Archivordner heißt weiterhin **Archiv**.
- Serverseitig werden zusätzlich `delimiter` und `depth` geliefert, damit Unterordner in der UI eingerückt dargestellt werden können.

### Signatur beim Schreiben
- Die bereits vorhandene **persönliche Standardsignatur aus System → Einstellungen → Mein Benutzerprofil** bleibt die primäre Standardsignatur und wird automatisch in neue Mails und Antworten eingefügt.
- Im Mail-Editor gibt es zusätzlich den Button **„Signatur“**, mit dem die Signatur entfernt oder erneut eingefügt werden kann.
- Wenn keine persönliche Signatur vorhanden ist, kann optional die im Postfach hinterlegte Postfach-Signatur als Fallback verwendet werden.
- Die Postfachbearbeitung zeigt dieses Fallback-Feld wieder an.

### Anhänge
Der Editor unterscheidet jetzt sichtbar zwischen:
- **Datei vom Rechner** – öffnet den normalen lokalen Dateidialog.
- **Dokument aus HCA** – öffnet eine durchsuchbare Dokumentauswahl.

Als HCA-Systemdokumente können im aktiven Test-/Produktionsmodus ausgewählt werden:
- Angebote (`AN-*`)
- Aufträge (`AU-*`)
- Kundenrechnungen (`RE-*` / lokale HCA-Rechnungen)
- Lieferscheine (`LS-*`)

Die PDFs werden beim Senden serverseitig aus dem jeweiligen aktuellen HCA-Datensatz erzeugt und als normale E-Mail-Anhänge übertragen. Lokale und HCA-Anhänge können kombiniert werden. Die bestehende Gesamtgrenze von 20 MB bleibt erhalten.

Neue Serverrouten:
- `GET /api/hca-shared/mail/system-documents`
- `GET /api/hca-shared/mail/system-documents/{doc_type}/{doc_id}/file`

### Bestehende Mailregeln bleiben erhalten
- Neue Mail / Weiterleiten: Absenderauswahl beim Senden.
- Antworten / Allen antworten: automatisch dasselbe empfangende Postfach als Absender.
- Benutzerbezogene Lese- und Senderechte aus v0.13.41 bleiben unverändert.
- Farbige HCA-Belegkennzeichnung bleibt erhalten.
- IMAP-UIDs und Thread-Header bleiben erhalten.

### Bestandsschutz / nicht geändert
- `main.py` wurde **nicht** geändert.
- Lager, PC-Barcodescanner v0.13.40, mobiler Scanner v0.13.39, Test-/Produktionsbetrieb v0.13.38, Merch, Einkauf, Lieferanten, Preise und Produktion wurden nicht verändert.
- Client v0.13.42 ergänzt v0.13.41 als separaten Overlay; die historischen Clientdateien bleiben im Paket erhalten.

### Teststatus v0.13.42
- `python -m py_compile app/hca_shared.py`: bestanden.
- IMAP-Parser-Test mit normalen Ordnern, echtem Archiv und Unterordnern unter `Archive`: bestanden; Unterordner behalten eigene Bezeichnungen.
- Systemdokument-Liste mit Testangebot im Testmodus: bestanden.
- Dokumentdatei-Routing wurde mit isolierter PDF-Erzeugung geprüft; die echte HCA-PDF-Erzeugung nutzt weiterhin die auf dem Produktionsserver vorhandenen Briefpapier-Assets.
- `node --check` für `hca-v01342.js`: bestanden; vollständiger Client-JS-Check erfolgt beim Paketbau.
- Physischer Live-Test mit den echten IMAP-Ordnern und realem Mailversand steht nach Installation noch aus.

## v0.13.41 – Outlook-artige E-Mail-Zentrale und Mehrkonto-Rechte

### Zielbild
Der Menüpunkt **E-Mail** ist jetzt als dreigeteilte Arbeitsansicht aufgebaut: links die für den angemeldeten HCA-Benutzer sichtbaren Postfächer und IMAP-Ordner, in der Mitte die Nachrichtenliste und rechts der Lesebereich. Direkt über dem Lesebereich liegt die Werkzeugleiste für Antworten, Allen antworten, Weiterleiten und Löschen.

### Mehrere Postfächer je Benutzer
- Jeder HCA-Benutzer kann im E-Mail-Bereich über `＋` eigene zusätzliche IMAP-/SMTP-Konten hinzufügen und eigene Konten bearbeiten.
- Postfach-Zugangsdaten bleiben zentral auf der Synology in `hca_mail_accounts.json`; Passwörter werden weiterhin nicht an den Client zurückgegeben.
- Bestehende Konten ohne Rechtefelder werden beim Lesen als Legacy-Konten behandelt und bleiben zunächst für alle Benutzer lesbar/sende-fähig, damit das Update keine vorhandene Mailfunktion abschaltet.
- Neue persönliche Konten sind standardmäßig für ihren Besitzer lesbar. Als Absender sind sie standardmäßig für alle HCA-Benutzer freigegeben; ein Administrator kann dies einschränken.

### Lese- und Senderechte
Administratoren sehen unter **System → Einstellungen → Kommunikation → E-Mail-Postfächer** eine zusätzliche Rechteverwaltung je Konto. Lesen und `Senden als` werden getrennt vergeben:
- `read_all_users` oder ausgewählte `read_user_ids`
- `send_all_users` oder ausgewählte `send_user_ids`
- Administratoren haben immer Zugriff.
- Der Besitzer eines persönlichen Kontos behält Lesen/Senden/Verwalten seines eigenen Kontos.

Dadurch sind Konfigurationen wie „Mitarbeiter A sieht nur sein persönliches Postfach, darf aber auch mit info@… senden“ möglich.

### IMAP / Outlook-artige Bedienung
- Server liest die tatsächliche IMAP-Ordnerliste.
- Bekannte Ordner werden als Posteingang, Gesendet, Entwürfe, Archiv, Papierkorb und Junk eingeordnet.
- Nachrichten werden mit echten IMAP-UIDs angesprochen; die vorherige Verwendung von Sequenznummern wurde ersetzt.
- Ungelesen-Status wird aus IMAP-Flags übernommen.
- Beim Öffnen wird die Nachricht als gelesen markiert.
- Löschen verschiebt nach Möglichkeit in den serverseitigen Papierkorb und markiert/entfernt die Ursprungsnachricht.

### Neue Nachricht / Antwortlogik
- Bei **Neue E-Mail** wird der Absender erst beim Klick auf `Senden` ausgewählt.
- Zur Auswahl stehen alle Konten, für die der Benutzer `Senden als` besitzt.
- Beim Weiterleiten wird ebenfalls der Absender gewählt.
- Beim **Antworten** und **Allen antworten** bleibt automatisch genau das Konto als Absender erhalten, über das die ursprüngliche E-Mail gelesen wurde.
- Antworten setzen `In-Reply-To` und `References`, damit Outlook/Apple Mail/Thunderbird die Antwort als denselben Thread erkennen können.
- Persönliche HCA-Signaturen aus dem Benutzerprofil bleiben im Editor erhalten.
- CC/BCC und Anhänge bis zur bestehenden 20-MB-Grenze bleiben unterstützt.

### Farbige Belegkennzeichnung
E-Mail-Betreff und bei geöffneter Nachricht zusätzlich der Text werden auf HCA-Belegnummern geprüft. Ein farbiges Badge wird nur erzeugt, wenn die Nummer tatsächlich in der HCA-Datenbank existiert:
- `AN-*` Angebot – blau
- `AU-*` Auftrag – orange
- `RE-*` / `ER-*` Rechnung – grün
- `LS-*` Lieferschein – türkis
- `PA-*` Produktionsauftrag – violett

Damit werden z. B. Antworten auf `Angebot AN-2026-0042` in der Nachrichtenliste sofort als Angebotskommunikation sichtbar.

### Dokumentversand
- Beim manuellen Versand eines Angebots wird jetzt ebenfalls die freigegebene Absenderadresse abgefragt.
- Beim manuellen Versand eines Lieferscheins wird ebenfalls die Absenderadresse abgefragt.
- Automatische Systemmails ohne Benutzerinteraktion verwenden weiterhin die vorhandene Standardadresse.
- Bestehende SMTP-Grundeinstellungen bleiben als Fallback erhalten.

### Server/API v0.13.41
Neu/erweitert:
- `GET /api/hca-shared/mail/accounts` – benutzergefilterte Konten inkl. `can_read/can_send/can_manage`
- `POST /api/hca-shared/mail/accounts` – eigenes Konto hinzufügen
- `PUT /api/hca-shared/mail/accounts/{id}` – eigenes/administriertes Konto bearbeiten
- `DELETE /api/hca-shared/mail/accounts/{id}` – eigenes/administriertes Konto aus HCA entfernen
- `PUT /api/hca-shared/mail/accounts/{id}/permissions` – Rechteverwaltung durch Administrator
- `GET /api/hca-shared/mail/accounts/{id}/folders` – IMAP-Ordner
- `GET /api/hca-shared/mail/accounts/{id}/messages?...` – UID-basierte Nachrichtenliste mit Tags
- `GET /api/hca-shared/mail/accounts/{id}/messages/{uid}?...` – Nachricht, Antwortheader, Anhänge-Metadaten und Tags
- `DELETE /api/hca-shared/mail/accounts/{id}/messages/{uid}?...` – Nachricht löschen
- `POST /api/hca-shared/mail/accounts/{id}/send` – Versand mit Rechteschutz und Thread-Headern

### Bestandsschutz / nicht geändert
- `main.py` wurde **nicht** geändert.
- Server-Freeze-Schutz bleibt unverändert.
- v0.13.40 PC-Wareneingang bleibt unverändert.
- v0.13.39 Mobile-Scanner bleibt unverändert.
- v0.13.38 Test-/Produktionsmodus bleibt unverändert.
- Merch, Einkauf, Artikelpreise, Lieferanten und Produktionsansichten wurden nicht verändert.

### Teststatus v0.13.41
- `python -m py_compile app/hca_shared.py`: bestanden.
- `node --check` für alle Client-JavaScriptdateien inklusive `hca-v01341.js`: bestanden.
- HTML-ID-Prüfung: keine doppelten IDs.
- `index.html`: weiterhin 0 literale `\n`-Sequenzen.
- `hca-v01341.js` und `hca-v01341.css` jeweils genau einmal eingebunden.
- Serverseitiger Test: Legacy-Mailkonto bleibt lesbar/sendbar; neues persönliches Konto erhält Besitzer- und Standardrechte; Administrator kann getrennte Lese-/Senderechte setzen.
- Serverseitiger IMAP-Mocktest: echte UID-Verwendung, Ungelesen-Flag, Detailabruf und Belegklassifikation bestanden.
- Belegklassifikation mit realen Testdatensätzen für `AN`, `AU` und `PA` bestanden.
- Physischer Live-Test gegen die echten IMAP-/SMTP-Konten steht noch aus, da deren Zugangsdaten in dieser Umgebung nicht vorliegen.

## v0.13.40 – schneller PC-Wareneingang mit USB-Barcodescanner

### Anlass
Der in NAS v0.13.39 eingebaute mobile `html5-qrcode`-Scanpfad hat auf dem realen iPhone des Nutzers keine Barcodes erkannt. Dieser physische Test ist damit fehlgeschlagen. v0.13.40 verlagert die gewünschte schnelle Einlagerung auf den bereits vorhandenen USB-Barcodescanner am PC und verändert dafür ausschließlich den Desktop-Client.

### Neuer Ablauf am PC
Im Bereich **Einkauf & Vertrieb → Einkauf → Wareneingang** wurde der bisherige Vier-Feld-Scannerblock durch einen schnellen Zwei-Schritt-Ablauf ersetzt:

1. Artikeletikett mit dem USB-Barcodescanner scannen.
2. Direkt danach den Barcode des Lagerfachs scannen.
3. HCA bucht genau **1 Stück** und ordnet es sofort diesem Fach zu.
4. Nach erfolgreicher Buchung wird automatisch wieder das Artikelfeld fokussiert.

Der Scanner kann weiterhin wie eine Tastatur arbeiten und `Enter` senden. Eine zusätzliche Klick-Bestätigung ist im Normalfall nicht mehr nötig.

### Alternative Auswahl ohne Fachscan
Nach dem Artikelscan werden zusätzlich die vorhandenen Lager als Buttons angezeigt. Nach Auswahl eines Lagers erscheinen die Regale/Fächer dieses Lagers als Buttons. Ein Klick auf ein Fach führt dieselbe Einlagerungsbuchung aus wie ein gescannter Fachbarcode.

### Bestellte Ware / manuelle Einlagerung
- **Bestellte Ware:** verwendet weiterhin den bestehenden Endpoint `purchase-orders/{line_id}/receive-to-bin`; Wareneingang und Fachzuordnung erfolgen gemeinsam.
- **Manuell einlagern:** verwendet weiterhin `inventory/manual-putaway`.
- Gibt es für dieselbe Lagerartikel-Variante mehrere offene Bestellpositionen, wird aus Sicherheitsgründen vor der Fachwahl die konkrete Bestellposition per Button verlangt. Es wird nicht stillschweigend eine möglicherweise falsche Lieferantenbestellung ausgewählt.

### Barcode-Modell – wichtiger Ist-Zustand
Die vorhandenen Artikelbarcodes sind **nicht pro physischem Einzelstück eindeutig**. `_barcode_for(stock_id)` erzeugt `HCA-S-...` aus der ID des Lagerartikels/der Variante. Mehrere Etiketten derselben Artikel-/Farb-/Größenvariante erhalten daher denselben Barcode.

Das passt zum aktuellen mengenbasierten Lagermodell (`inventory_stock_items` + Mengen pro Fach). v0.13.40 bucht deshalb im neuen Schnellablauf pro Artikel-/Fach-Scan genau 1 Stück. Eine echte Seriennummer pro physischem Stück würde eine separate Datenmodell-Erweiterung (Einzelstück-/Unit-Tabelle, serialisierte Etiketten und angepasste Bewegungen) erfordern und ist in v0.13.40 bewusst nicht enthalten.

### Nicht geändert
- NAS-Code v0.13.39 bleibt unverändert.
- `main.py` unverändert.
- Test-/Produktionsmodus v0.13.38 unverändert.
- Merch, Artikelpreise, Lieferanten, Einkauf und Produktionsansichten unverändert.
- Die mobile v0.13.39-Datei wird in diesem Desktop-Update nicht verändert.

### Teststatus v0.13.40
- `node --check hca-v01340.js`: bestanden.
- `index.html`: `hca-v01340.js` und `hca-v01340.css` jeweils genau einmal eingebunden.
- `index.html`: weiterhin 0 literale `\\n`-Sequenzen.
- Bestehende kumulative Client-Dateien bis v0.13.38 sind byteidentisch zur v0.13.39-Clientbasis.
- Neuer Ablauf nutzt ausschließlich bestehende, bereits vorhandene NAS-Routen; kein NAS-Update erforderlich.
- Physischer Test mit dem neuen USB-Barcodescanner am realen PC steht noch aus.

## v0.13.39 – iPhone-Scanner auf bewährten html5-qrcode-Code-128-Pfad umgestellt

### Ziel
Die mobile HCA-Lager-App behält ihr bestehendes Aussehen und ihren bisherigen Lager-Workflow. Nur der fehleranfällige iPhone-Scanpfad wurde ersetzt.

### iPhone/iPad
- Quagga2 ist aus dem aktiven iOS-Scanpfad entfernt.
- Verwendet wird `html5-qrcode` 2.3.8.
- Es ist ausschließlich `Html5QrcodeSupportedFormats.CODE_128` freigeschaltet.
- Die Kameraauswahl folgt der früher auf dem iPhone bewährten Dolibarr-Logik: `Html5Qrcode.getCameras()` → Rückkamera anhand `back/rear/environment/hinten/rück` bevorzugen → Start über konkrete `deviceId`; wenn keine Kamera eindeutig beschriftet ist, wird die letzte gelistete Kamera verwendet.
- Der bestehende HCA-Scanrahmen, Kamera-Bereich, Statusmeldungen, Navigation und alle vier Lager-Modi bleiben optisch erhalten.
- Die vorhandene HCA-Validierung bleibt erhalten: Artikel-/Fachbarcodes werden weiterhin über `/inventory/location-scan/{barcode}` serverseitig geprüft, bevor ein Lager-Workflow fortgesetzt wird.
- Manuelle Barcodeeingabe bleibt als Fallback verfügbar.

### Andere Plattformen
- Bestehender nativer `BarcodeDetector`-Pfad und ZXing-Fallback bleiben unverändert.

### Nicht geändert
- Kein Desktop-Client-Code geändert; v0.13.38 bleibt der aktuelle Desktop-Stand.
- `main.py` nicht geändert.
- Test-/Produktionsmodus v0.13.38 nicht geändert.
- Artikel/Lieferanten/Preise/Merch/Einkauf nicht geändert.

### Teststatus v0.13.39
- `python -m py_compile app/hca_shared.py`: bestanden.
- Aus `MOBILE_HTML` extrahiertes JavaScript: `node --check` bestanden.
- Quagga/Quagga2-Referenzen im ausgelieferten `hca_shared.py`: 0.
- `Html5Qrcode.getCameras()`, Rückkameraauswahl und konkrete `deviceId` vorhanden.
- Scannerformat auf `CODE_128` beschränkt.
- Sichtbare HCA-Mobile-Struktur und bestehende Bedienelemente wurden nicht neu gestaltet; hinzugefügt wurde nur ein unsichtbarer interner Reader-Container innerhalb des bestehenden Kamerafensters.
- Physischer iPhone-Test steht noch aus; keine Aussage, dass die reale Kamera bereits verifiziert wurde.

## v0.13.38 – Getrennter Test- und Produktionsbetrieb

### Ziel
HCA besitzt jetzt zwei logisch getrennte Datenräume:

- **Testbetrieb**: ausschließlich Testbelege und Test-Produktionsaufträge.
- **Produktionsbetrieb**: ausschließlich echte Belege und echte Produktionsaufträge.

Der Betriebsmodus ist eine zentrale Einstellung auf der Synology. Ein Wechsel ändert nicht die Zuordnung vorhandener Datensätze, sondern nur den sichtbaren/aktiven Datenraum und die Zuordnung neu angelegter Daten.

### Einmalige Migration
Beim ersten Start mit NAS v0.13.38 werden alle bereits vorhandenen Belege und Produktionsaufträge absichtlich dem **Testbetrieb** zugeordnet. Das betrifft insbesondere:

- Angebote
- Kundenaufträge
- Produktionsauftrags-Verknüpfungen
- zentrale Produktionsaufträge einschließlich Positionen/Tasks/Versandgruppen
- Kunden- und Lieferantenrechnungen
- Lieferscheine
- HCA-Sendungen und Auftrags-Metadaten

Stammdaten wie Kunden, Artikel, Lager, Lieferanten und Einstellungen werden nicht in Test/Produktion dupliziert und bleiben gemeinsam verfügbar.

### Zentrale Datenmarkierung
Die betroffenen Tabellen erhalten `environment = test | production`.

In `hca_shared.sqlite3` betrifft das:
- `sales_quotes`
- `sales_orders`
- `production_order_links`
- `finance_invoices`
- `finance_credit_notes`
- `delivery_notes`
- `order_meta`
- `shipments`

In `hca_production.sqlite3` betrifft das:
- `orders`
- `items`
- `tasks`
- `shipping_groups`

SQLite-Trigger weisen neuen Datensätzen automatisch den aktuell eingestellten Betriebsmodus zu. Untergeordnete Produktionsdatensätze übernehmen den Modus des Elternauftrags. Für WooCommerce-Refreshes existiert eine kleine Shadow-Tabelle, damit der Modus eines vorhandenen Auftrags beim internen Löschen/Neuaufbauen mit derselben Auftrags-ID erhalten bleibt.

`main.py` wurde dafür **nicht geändert**. Die bestehende Produktionsserver-/Freeze-Logik bleibt unangetastet.

### Sichtbarkeit
Die Business-Listen auf der NAS filtern serverseitig nach dem aktiven Modus:
- Dashboard
- Angebote
- Aufträge
- Rechnungen
- Lieferscheine
- Versand/Sendungen
- Auftrags-Metadaten
- Suche
- Kundenhistorie
- Produktionsauftrags-Verknüpfungen

Externe Lexware-Belege gelten als reale externe Buchhaltungsdaten und werden im Testbetrieb nicht angezeigt.

Die ältere zentrale Produktions-API aus `main.py` liefert durch die Schemaerweiterung das Feld `environment` mit. Der v0.13.38-Client filtert `/api/orders`, `/api/tasks` und `/api/shipping-groups` zusätzlich nach dem zentral eingestellten Modus. Dadurch werden Test- und Produktions-Produktionsaufträge im HCA-Client nicht vermischt, ohne `main.py` zu ersetzen.

### Lager-/Bedarfsberechnung
Test- und Produktionsaufträge dürfen sich nicht gegenseitig Bestände reservieren. Deshalb berücksichtigt die Reservierungs-/Beschaffungsberechnung nur die Aufträge des gerade aktiven Betriebsmodus. Verdeckte Reservierungen des anderen Modus bleiben erhalten, fließen aber nicht in die aktive Bedarfsberechnung ein.

### Einstellungen
Unter **System → Einstellungen → Allgemein** gibt es den neuen Bereich **Betriebsmodus**.

- Umschalter **Testbetrieb / Produktionsbetrieb**
- deutliche Erklärung des jeweils aktiven Modus
- Anzeige der vorhandenen Testdatenmengen
- Warnbestätigung beim Wechsel in den Produktionsbetrieb
- deutlich sichtbare Modusanzeige im HCA-Fenster; im Testbetrieb steht dort `⚠ TESTBETRIEB`

### Löschen von Testdaten
Löschen ist ausschließlich im Testbetrieb möglich. Es gibt:

- **Alle Testbelege löschen** in den Einstellungen
- einzelne Testangebote löschen
- einzelne Testaufträge löschen
- einzelne Testrechnungen löschen
- einzelne Testlieferscheine löschen
- einzelne mit einem Auftrag verknüpfte Test-Produktionsaufträge löschen

Die Serverendpunkte prüfen zusätzlich den Modus des Datensatzes. Ein Produktionsdatensatz wird von diesen Funktionen auch dann nicht gelöscht, wenn später in den Testbetrieb zurückgeschaltet wird.

Beim Löschen eines Testauftrags werden seine Test-Folgedaten konsistent mit entfernt bzw. entkoppelt: Produktionsauftrags-Verknüpfungen, zentrale Test-Produktionsaufträge, Testrechnungen, Testlieferscheine, Testsendungen und zugehörige Reservierungen. Produktionsdaten werden nicht berührt.

### Weiterhin enthalten
- v0.13.37: exakte Untermenü-Markierung, aufgeteilte Einstellungen, einmaliger Hinweis „Vorschlag: Eigenproduktion“, reparierte Produktionsauftrags-Schaltflächen.
- v0.13.36: Artikel-Reiter Preise, Mehrlieferanten, Einkaufspreise je Lieferant, bevorzugter Lieferant, automatische Zuordnung F&R/Axpol/Probo.
- v0.13.35: Merch-Persistenz, korrekte Mengenrekonstruktion, `HCA-MERCH:*`-Versandgruppen, originale Merch-/Serienproduktionsansicht und Stickdatei-/Maschinenworkflow.
- v0.13.33: Neue Bestellung/Bestellungen, Bestellhistorie, PC-Wareneingang und Lagerplätze.
- v0.13.32: Artikelverwaltung, Variantenfilter und F&R-Beschaffungsfunktionen.

## Teststatus v0.13.38
- `python -m py_compile app/hca_shared.py`: bestanden.
- `node --check hca-v01338.js`: bestanden.
- SQLite-Migrationstest: vorhandene Produktionsaufträge werden `test`: bestanden.
- Neuanlage im Produktionsbetrieb erhält `production`; Items/Tasks erben den Modus: bestanden.
- WooCommerce-artiges Löschen/Neuaufbauen derselben Produktionsauftrags-ID bewahrt den ursprünglichen Modus über die Shadow-Tabelle: bestanden.
- Shared-Belege erhalten automatisch den aktiven Modus: bestanden.
- Zugriff auf Testbeleg über Produktions-Datenraum wird serverseitig abgewiesen: bestanden.
- Sammellöschung im Testbetrieb löscht Testdaten und lässt Produktionsdaten bestehen: bestanden.
- `index.html`: 0 literale `\\n`-Sequenzen.
- `hca-v01338.js` und `hca-v01338.css` jeweils exakt einmal eingebunden.
- Bestehende kumulative Client-Dateien bis v0.13.37 werden nicht verändert.
- `main.py` wird nicht verändert.

## Architekturregeln
- Gemeinsamer Geschäfts-/Produktionszustand liegt zentral auf der Synology.
- Arbeitsplatz-/Hardwareeinstellungen bleiben lokal.
- Blocking I/O auf der NAS darf den FastAPI-Eventloop nicht blockieren; bestehende `asyncio.to_thread`-Schutzlogik bleibt erhalten.
- `main.py` nur ändern, wenn zwingend erforderlich; v0.13.38 kommt ohne Änderung aus.
- Nach jeder Änderung `PROJECT_STATUS.md` fortschreiben.

- KoSIT-Aufrufe aus HTTP-Routen laufen ausschließlich über `asyncio.to_thread`; die XML-Ablage selbst startet keinen synchronen Java-Prozess.
