(function () {
  'use strict';

  const state = { input: null, resolve: null, view: new Date() };
  const pad = value => String(value).padStart(2, '0');
  const iso = date => `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  const parseIso = value => {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ''));
    if (!match) return null;
    const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
    return Number.isNaN(date.getTime()) ? null : date;
  };

  function ensurePicker() {
    let dialog = document.getElementById('hcaDatePicker');
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.id = 'hcaDatePicker';
    dialog.className = 'hca-date-dialog';
    dialog.setAttribute('aria-label', 'Datum auswählen');
    dialog.innerHTML = `
      <div class="hca-date-head">
        <button type="button" data-date-action="prev" aria-label="Vorheriger Monat">‹</button>
        <strong id="hcaDateTitle"></strong>
        <button type="button" data-date-action="next" aria-label="Nächster Monat">›</button>
      </div>
      <div class="hca-date-weekdays" aria-hidden="true">
        <span>Mo</span><span>Di</span><span>Mi</span><span>Do</span><span>Fr</span><span>Sa</span><span>So</span>
      </div>
      <div class="hca-date-grid" id="hcaDateGrid"></div>
      <div class="hca-date-actions">
        <button type="button" class="btn secondary" data-date-action="clear">Leeren</button>
        <button type="button" class="btn secondary" data-date-action="today">Heute</button>
        <button type="button" class="btn primary" data-date-action="cancel">Abbrechen</button>
      </div>`;
    document.body.appendChild(dialog);
    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      closePicker(null);
    });
    dialog.addEventListener('click', event => {
      if (event.target === dialog) closePicker(null);
      const button = event.target.closest('button');
      if (!button) return;
      const day = button.dataset.dateValue;
      if (day) return closePicker(day);
      const action = button.dataset.dateAction;
      if (action === 'prev') state.view = new Date(state.view.getFullYear(), state.view.getMonth() - 1, 1);
      if (action === 'next') state.view = new Date(state.view.getFullYear(), state.view.getMonth() + 1, 1);
      if (action === 'today') return closePicker(iso(new Date()));
      if (action === 'clear') return closePicker('');
      if (action === 'cancel') return closePicker(null);
      if (action === 'prev' || action === 'next') renderPicker();
    });
    return dialog;
  }

  function renderPicker() {
    const dialog = ensurePicker();
    const year = state.view.getFullYear();
    const month = state.view.getMonth();
    dialog.querySelector('#hcaDateTitle').textContent = new Intl.DateTimeFormat('de-DE', {
      month: 'long', year: 'numeric'
    }).format(state.view);
    const first = new Date(year, month, 1);
    const offset = (first.getDay() + 6) % 7;
    const selected = state.input ? state.input.value : '';
    const today = iso(new Date());
    const cells = [];
    for (let index = 0; index < 42; index += 1) {
      const date = new Date(year, month, index - offset + 1);
      const value = iso(date);
      const classes = [date.getMonth() === month ? '' : 'outside'];
      if (value === selected) classes.push('selected');
      if (value === today) classes.push('today');
      cells.push(`<button type="button" class="${classes.join(' ').trim()}" data-date-value="${value}" aria-label="${date.toLocaleDateString('de-DE')}">${date.getDate()}</button>`);
    }
    dialog.querySelector('#hcaDateGrid').innerHTML = cells.join('');
  }

  function openPicker(input, resolver) {
    state.input = input || null;
    state.resolve = resolver || null;
    const current = parseIso(input && input.value) || new Date();
    state.view = new Date(current.getFullYear(), current.getMonth(), 1);
    renderPicker();
    const dialog = ensurePicker();
    if (!dialog.open) dialog.showModal();
  }

  function closePicker(value) {
    const dialog = ensurePicker();
    if (dialog.open) dialog.close();
    if (value !== null && state.input) {
      state.input.value = value;
      state.input.dispatchEvent(new Event('input', { bubbles: true }));
      state.input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    const resolve = state.resolve;
    state.input = null;
    state.resolve = null;
    if (resolve) resolve(value);
  }

  function upgradeDateInput(input) {
    if (!input || input.dataset.hcaDatepicker === 'true') return;
    input.dataset.hcaDatepicker = 'true';
    input.type = 'text';
    input.inputMode = 'none';
    input.readOnly = true;
    input.autocomplete = 'off';
    input.placeholder = input.placeholder || 'JJJJ-MM-TT';
    const wrapper = document.createElement('span');
    wrapper.className = 'hca-date-field';
    input.parentNode.insertBefore(wrapper, input);
    wrapper.appendChild(input);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hca-date-button';
    button.setAttribute('aria-label', 'Datum auswählen');
    button.textContent = '▦';
    wrapper.appendChild(button);
    const show = event => {
      event.preventDefault();
      if (!input.disabled) openPicker(input);
    };
    button.addEventListener('click', show);
    input.addEventListener('click', show);
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ' || event.key === 'ArrowDown') show(event);
    });
  }

  function upgradeDateInputs(root) {
    if (root instanceof HTMLInputElement && root.matches('input[type="date"]')) upgradeDateInput(root);
    root.querySelectorAll && root.querySelectorAll('input[type="date"]').forEach(upgradeDateInput);
  }

  window.hcaPickDate = function (initialValue) {
    const virtualInput = document.createElement('input');
    virtualInput.value = initialValue || '';
    return new Promise(resolve => openPicker(virtualInput, resolve));
  };

  const messageState = { queue: [], active: false };

  function ensureMessageDialog() {
    let dialog = document.getElementById('hcaMessageDialog');
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.id = 'hcaMessageDialog';
    dialog.className = 'hca-message-dialog';
    dialog.setAttribute('aria-labelledby', 'hcaMessageTitle');
    dialog.innerHTML = `
      <div class="hca-message-brand">
        <img src="/assets/logo-app.png" alt="Werbestudio Königswinter">
        <div><small>HCA PRODUKTIONSMANAGER</small><strong id="hcaMessageTitle">Hinweis</strong></div>
      </div>
      <div class="hca-message-content">
        <div class="hca-message-symbol" id="hcaMessageSymbol" aria-hidden="true">i</div>
        <p id="hcaMessageText"></p>
        <input id="hcaMessageInput" class="text-input hidden" autocomplete="off">
      </div>
      <div class="hca-message-actions">
        <button type="button" class="btn secondary hidden" id="hcaMessageCancel">Abbrechen</button>
        <button type="button" class="btn primary" id="hcaMessageAccept">OK</button>
      </div>`;
    document.body.appendChild(dialog);
    dialog.addEventListener('cancel', event => {
      event.preventDefault();
      finishMessageDialog(dialog.dataset.kind === 'alert' ? true : null);
    });
    dialog.querySelector('#hcaMessageCancel').addEventListener('click', () => finishMessageDialog(null));
    dialog.querySelector('#hcaMessageAccept').addEventListener('click', () => {
      const kind = dialog.dataset.kind;
      finishMessageDialog(kind === 'prompt' ? dialog.querySelector('#hcaMessageInput').value : true);
    });
    dialog.querySelector('#hcaMessageInput').addEventListener('keydown', event => {
      if (event.key === 'Enter') finishMessageDialog(event.currentTarget.value);
    });
    return dialog;
  }

  function showNextMessageDialog() {
    if (messageState.active || !messageState.queue.length) return;
    messageState.active = true;
    const item = messageState.queue[0];
    const dialog = ensureMessageDialog();
    const isQuestion = item.kind === 'confirm' || item.kind === 'prompt';
    dialog.dataset.kind = item.kind;
    dialog.querySelector('#hcaMessageTitle').textContent = item.title || (item.kind === 'alert' ? 'Hinweis' : 'Bestätigung');
    dialog.querySelector('#hcaMessageText').textContent = String(item.message ?? '');
    dialog.querySelector('#hcaMessageSymbol').textContent = item.kind === 'alert' ? 'i' : '?';
    const input = dialog.querySelector('#hcaMessageInput');
    input.classList.toggle('hidden', item.kind !== 'prompt');
    input.value = item.defaultValue == null ? '' : String(item.defaultValue);
    dialog.querySelector('#hcaMessageCancel').classList.toggle('hidden', !isQuestion);
    dialog.querySelector('#hcaMessageAccept').textContent = item.kind === 'alert' ? 'OK' : 'Bestätigen';
    dialog.showModal();
    setTimeout(() => (item.kind === 'prompt' ? input : dialog.querySelector('#hcaMessageAccept')).focus(), 30);
  }

  function finishMessageDialog(value) {
    const dialog = ensureMessageDialog();
    const item = messageState.queue.shift();
    if (dialog.open) dialog.close();
    messageState.active = false;
    if (item) item.resolve(value);
    showNextMessageDialog();
  }

  function queueMessageDialog(kind, message, defaultValue, title) {
    return new Promise(resolve => {
      messageState.queue.push({ kind, message, defaultValue, title, resolve });
      showNextMessageDialog();
    });
  }

  window.hcaAlert = (message, title = 'Hinweis') => queueMessageDialog('alert', message, '', title);
  window.hcaConfirm = (message, title = 'Bitte bestätigen') => queueMessageDialog('confirm', message, '', title).then(Boolean);
  window.hcaPrompt = (message, defaultValue = '', title = 'Eingabe') => queueMessageDialog('prompt', message, defaultValue, title);

  // Native Browserdialoge dürfen in HCA nicht mehr erscheinen. Alerts werden
  // bewusst nicht blockierend in die HCA-Dialogwarteschlange gestellt.
  window.alert = message => { void window.hcaAlert(message); };
  window.confirm = () => false;
  window.prompt = () => null;

  function init() {
    upgradeDateInputs(document);
    new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
      if (node.nodeType === Node.ELEMENT_NODE) upgradeDateInputs(node);
    }))).observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
