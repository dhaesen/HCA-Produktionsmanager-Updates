Dieser Ordner ist für lokale HCA-Clientdaten vorgesehen.
Bei Updates und Reparaturinstallationen wird ein vorhandener data-Ordner nicht überschrieben.
