# HCA Pico 2 W bridge: WiFi HTTP -> virtual USB MSC in SFR/USB-Floppy-1.40i layout.
import gc
import json
import machine
import network
import socket
import struct
import time
from hca_disk import HcaFloppyDisk, SECTOR_SIZE, TOTAL_SECTORS, MAX_PATTERN_BYTES

BRIDGE_VERSION = "0.3-bootfix"
CONFIG_FILE = "hca_config.json"
PATTERN_FILE = "pattern.bin"
PATTERN_META = "pattern.meta"
EP_OUT = 0x01
EP_IN = 0x81


def _load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            c = json.load(f)
        return {"ssid": str(c.get("ssid", "")), "password": str(c.get("password", ""))}
    except Exception:
        return {"ssid": "", "password": ""}


def _json_bytes(obj):
    return json.dumps(obj).encode("utf-8")


def _percent_decode(s):
    s = s.replace("+", " ")
    out = bytearray()
    i = 0
    raw = s.encode("utf-8")
    while i < len(raw):
        if raw[i] == 37 and i + 2 < len(raw):
            try:
                out.append(int(bytes(raw[i + 1:i + 3]), 16))
                i += 3
                continue
            except Exception:
                pass
        out.append(raw[i]); i += 1
    try:
        return out.decode("utf-8")
    except Exception:
        # MicroPython RP2 does not provide the latin1 codec.
        # Preserve byte values 1:1 without relying on an optional codec.
        return "".join(chr(b) for b in out)


class UsbMsc:
    def __init__(self, disk):
        self.disk = disk
        self.usbd = machine.USBDevice()
        self.cbw = bytearray(31)
        self.csw = bytearray(13)
        self.sector = bytearray(SECTOR_SIZE)
        self.discard = bytearray(64)
        self.state = "idle"
        self.tag = 0
        self.expected = 0
        self.sent = 0
        self.read_lba = 0
        self.read_count = 0
        self.status = 0
        self.sense_key = 0
        self.sense_asc = 0
        self.sense_ascq = 0
        self.active = False

    def _device_descriptor(self):
        return bytes([
            18, 1, 0x00, 0x02, 0, 0, 0, 64,
            0x55, 0xF0, 0x43, 0x48, 0x00, 0x02,
            1, 2, 3, 1,
        ])

    def _config_descriptor(self):
        return bytes([
            9, 2, 32, 0, 1, 1, 0, 0x80, 50,
            9, 4, 0, 0, 2, 0x08, 0x06, 0x50, 0,
            7, 5, EP_IN,  0x02, 64, 0, 0,
            7, 5, EP_OUT, 0x02, 64, 0, 0,
        ])

    def start(self):
        try:
            self.usbd.active(False)
        except Exception:
            pass
        self.usbd.builtin_driver = self.usbd.BUILTIN_NONE
        self.usbd.config(
            desc_dev=self._device_descriptor(),
            desc_cfg=self._config_descriptor(),
            desc_strs={1: "HCA", 2: "HCA Pico Floppy 1.40i", 3: "HCA4-PICO"},
            open_itf_cb=self._open_cb,
            reset_cb=self._reset_cb,
            control_xfer_cb=self._control_cb,
            xfer_cb=self._xfer_cb,
        )
        self.usbd.active(True)
        self.active = True

    def pause(self):
        try:
            self.usbd.active(False)
        except Exception:
            pass
        self.active = False

    def resume(self):
        self.disk.reload()
        try:
            self.usbd.active(True)
            self.active = True
        except Exception:
            self.start()

    def _open_cb(self, desc):
        self.state = "cbw"
        self._queue_cbw()

    def _reset_cb(self):
        self.state = "idle"

    def _control_cb(self, stage, req):
        # USB MSC Bulk-Only class requests.
        bm, breq, wv, wi, wl = struct.unpack("<BBHHH", req)
        if stage == 1:
            if bm == 0xA1 and breq == 0xFE and wl == 1:  # GET_MAX_LUN
                return b"\x00"
            if bm == 0x21 and breq == 0xFF and wl == 0:  # BULK_ONLY_RESET
                return True
            return False
        if stage == 3 and bm == 0x21 and breq == 0xFF:
            self.state = "cbw"
            try:
                self._queue_cbw()
            except Exception:
                pass
        return True

    def _queue_cbw(self):
        self.state = "cbw"
        if not self.usbd.submit_xfer(EP_OUT, self.cbw):
            pass

    def _set_sense(self, key, asc, ascq=0):
        self.sense_key, self.sense_asc, self.sense_ascq = key, asc, ascq

    def _send_data(self, data, status=0):
        self.status = status
        self.sent = min(len(data), self.expected)
        self.state = "small_in"
        self._small = data[:self.sent]
        self.usbd.submit_xfer(EP_IN, self._small)

    def _send_csw(self, status=None):
        if status is not None:
            self.status = status
        residue = self.expected - self.sent
        if residue < 0:
            residue = 0
        struct.pack_into("<IIIB", self.csw, 0, 0x53425355, self.tag, residue, self.status)
        self.state = "csw"
        self.usbd.submit_xfer(EP_IN, self.csw)

    def _discard_out(self, remaining, status=1):
        self._discard_remaining = remaining
        self.status = status
        self.sent = 0
        if remaining <= 0:
            self._send_csw(status)
            return
        self.state = "discard"
        n = 64 if remaining > 64 else remaining
        self.usbd.submit_xfer(EP_OUT, memoryview(self.discard)[:n])

    def _handle_cbw(self):
        if struct.unpack_from("<I", self.cbw, 0)[0] != 0x43425355:
            self.usbd.stall(EP_OUT, True)
            return
        self.tag = struct.unpack_from("<I", self.cbw, 4)[0]
        self.expected = struct.unpack_from("<I", self.cbw, 8)[0]
        flags = self.cbw[12]
        cb_len = self.cbw[14] & 0x1F
        cdb = self.cbw[15:15 + cb_len]
        op = cdb[0] if cdb else 0xFF
        self.sent = 0
        self.status = 0

        if op == 0x00:  # TEST UNIT READY
            self._send_csw(0)
        elif op == 0x03:  # REQUEST SENSE
            d = bytearray(18); d[0] = 0x70; d[2] = self.sense_key; d[7] = 10; d[12] = self.sense_asc; d[13] = self.sense_ascq
            self._send_data(d, 0)
            self._set_sense(0, 0, 0)
        elif op == 0x12:  # INQUIRY
            d = bytearray(36); d[0] = 0; d[1] = 0x80; d[2] = 0x04; d[3] = 0x02; d[4] = 31
            d[8:16] = b"HCA     "; d[16:32] = b"PICO FLOPPY     "; d[32:36] = b"0200"
            self._send_data(d, 0)
        elif op == 0x1A:  # MODE SENSE(6), write protected
            alloc = cdb[4] if len(cdb) > 4 else 4
            d = bytearray(4); d[0] = 3; d[2] = 0x80
            self._send_data(d[:alloc], 0)
        elif op in (0x1B, 0x1E, 0x2F, 0x35):
            self._send_csw(0)
        elif op == 0x23:  # READ FORMAT CAPACITIES
            d = bytearray(12); d[3] = 8
            struct.pack_into(">I", d, 4, TOTAL_SECTORS)
            d[8] = 0x02; d[9] = 0x00; d[10] = 0x02; d[11] = 0x00
            self._send_data(d, 0)
        elif op == 0x25:  # READ CAPACITY(10)
            d = struct.pack(">II", TOTAL_SECTORS - 1, SECTOR_SIZE)
            self._send_data(d, 0)
        elif op in (0x08, 0x28, 0xA8, 0x88):  # READ(6/10/12/16)
            if op == 0x08 and len(cdb) >= 6:
                self.read_lba = ((cdb[1] & 0x1F) << 16) | (cdb[2] << 8) | cdb[3]
                self.read_count = cdb[4] or 256
            elif op == 0x28 and len(cdb) >= 10:
                self.read_lba = struct.unpack_from(">I", cdb, 2)[0]
                self.read_count = struct.unpack_from(">H", cdb, 7)[0]
            elif op == 0xA8 and len(cdb) >= 12:
                self.read_lba = struct.unpack_from(">I", cdb, 2)[0]
                self.read_count = struct.unpack_from(">I", cdb, 6)[0]
            elif op == 0x88 and len(cdb) >= 16:
                hi = struct.unpack_from(">I", cdb, 2)[0]
                lo = struct.unpack_from(">I", cdb, 6)[0]
                self.read_lba = (hi << 32) | lo
                self.read_count = struct.unpack_from(">I", cdb, 10)[0]
            else:
                self._set_sense(0x05, 0x24, 0); self._send_csw(1); return
            if self.read_count == 0:
                self._send_csw(0)
            elif self.read_lba + self.read_count > TOTAL_SECTORS:
                self._set_sense(0x05, 0x21, 0)
                self._send_csw(1)
            else:
                self.state = "read"
                self._send_next_sector()
        elif op in (0x0A, 0x2A, 0xAA, 0x8A):  # WRITE(6/10/12/16) - read-only medium
            self._set_sense(0x07, 0x27, 0)
            self._discard_out(self.expected, 1)
        elif op == 0x9E and len(cdb) >= 16 and (cdb[1] & 0x1F) == 0x10:  # READ CAPACITY(16)
            d = bytearray(32)
            # 64-bit last LBA, high 32 bits are zero for this device.
            struct.pack_into(">I", d, 4, TOTAL_SECTORS - 1)
            struct.pack_into(">I", d, 8, SECTOR_SIZE)
            self._send_data(d, 0)
        elif op == 0x5A:  # MODE SENSE(10), write protected
            d = bytearray(8); d[1] = 6; d[3] = 0x80
            self._send_data(d, 0)
        elif op == 0xA0:  # REPORT LUNS
            d = bytearray(16); d[3] = 8
            self._send_data(d, 0)
        else:
            self._set_sense(0x05, 0x20, 0)  # illegal request / invalid command
            if self.expected and not (flags & 0x80):
                self._discard_out(self.expected, 1)
            else:
                self._send_csw(1)

    def _send_next_sector(self):
        if self.read_count <= 0 or self.sent >= self.expected:
            self._send_csw(0)
            return
        self.disk.read_sector(self.read_lba, self.sector)
        remaining = self.expected - self.sent
        n = SECTOR_SIZE if remaining >= SECTOR_SIZE else remaining
        self.state = "read"
        self.usbd.submit_xfer(EP_IN, memoryview(self.sector)[:n])

    def _xfer_cb(self, ep, result, n):
        # XFER_SUCCESS is integer 0. Old MicroPython docs described this backwards.
        if result != 0:
            if ep == EP_OUT:
                try: self._queue_cbw()
                except Exception: pass
            return
        if ep == EP_OUT:
            if self.state == "cbw":
                if n == 31:
                    self._handle_cbw()
                else:
                    self._queue_cbw()
            elif self.state == "discard":
                self.sent += n
                self._discard_remaining -= n
                if self._discard_remaining > 0:
                    m = 64 if self._discard_remaining > 64 else self._discard_remaining
                    self.usbd.submit_xfer(EP_OUT, memoryview(self.discard)[:m])
                else:
                    self._send_csw(self.status)
        elif ep == EP_IN:
            if self.state == "read":
                self.sent += n
                self.read_lba += 1
                self.read_count -= 1
                self._send_next_sector()
            elif self.state == "small_in":
                self._send_csw(self.status)
            elif self.state == "csw":
                self._queue_cbw()


def _send_http(cl, status, body, content_type="application/json"):
    if isinstance(body, str):
        body = body.encode("utf-8")
    reason = "OK" if status < 400 else "Error"
    hdr = (
        "HTTP/1.1 %d %s\r\n" % (status, reason)
        + "Content-Type: %s\r\n" % content_type
        + "Content-Length: %d\r\n" % len(body)
        + "Access-Control-Allow-Origin: *\r\n"
        + "Access-Control-Allow-Methods: GET,POST,OPTIONS\r\n"
        + "Access-Control-Allow-Headers: Content-Type\r\n"
        + "Connection: close\r\n\r\n"
    ).encode("ascii")
    cl.send(hdr); cl.send(body)


def _read_request(cl):
    data = bytearray()
    while b"\r\n\r\n" not in data and len(data) < 8192:
        b = cl.recv(512)
        if not b: break
        data.extend(b)
    pos = data.find(b"\r\n\r\n")
    if pos < 0:
        return None
    # HTTP request headers used here are ASCII. Avoid the unavailable
    # latin1 codec on MicroPython RP2.
    head = bytes(data[:pos]).decode()
    rest = bytes(data[pos + 4:])
    lines = head.split("\r\n")
    first = lines[0].split(" ")
    if len(first) < 2:
        return None
    headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1); headers[k.strip().lower()] = v.strip()
    return first[0].upper(), first[1], headers, rest


def _save_pattern(cl, headers, initial, name, msc, disk):
    try:
        length = int(headers.get("content-length", "0"))
    except Exception:
        length = 0
    if length <= 0 or length > MAX_PATTERN_BYTES:
        _send_http(cl, 413, _json_bytes({"ok": False, "error": "Datei zu gross oder leer"}))
        return
    msc.pause()
    disk.close()
    ok = False
    try:
        received = 0
        with open(PATTERN_FILE + ".tmp", "wb") as f:
            if initial:
                part = initial[:length]; f.write(part); received += len(part)
            while received < length:
                b = cl.recv(min(4096, length - received))
                if not b: break
                f.write(b); received += len(b)
        if received != length:
            raise OSError("Upload unvollstaendig")
        try:
            import os
            try: os.remove(PATTERN_FILE)
            except OSError: pass
            os.rename(PATTERN_FILE + ".tmp", PATTERN_FILE)
        except Exception:
            pass
        with open(PATTERN_META, "w") as f:
            f.write("%s\t%d" % (name, length))
        disk.reload(); ok = True
        info = disk.info(); info.update({"ok": True, "bridge_version": BRIDGE_VERSION})
        _send_http(cl, 200, _json_bytes(info))
    except Exception as e:
        _send_http(cl, 500, _json_bytes({"ok": False, "error": str(e)}))
    finally:
        msc.resume()
        if not ok:
            gc.collect()


_disk = None
_msc = None

def boot_usb():
    # boot.py calls this before the built-in USB subsystem is finalised.
    # If no config exists, leave MicroPython's normal USB-CDC active for setup.
    global _disk, _msc
    cfg = _load_config()
    if not cfg.get("ssid"):
        return False
    _disk = HcaFloppyDisk(PATTERN_FILE, PATTERN_META)
    _msc = UsbMsc(_disk)
    # USB MSC is started by run() only after WiFi + HTTP are alive.
    return True

def run():
    global _disk, _msc
    cfg = _load_config()
    if not cfg.get("ssid"):
        print("HCA_PICO_SETUP_READY")
        return
    if _disk is None or _msc is None:
        boot_usb()
    disk, msc = _disk, _msc

    try:
        network.hostname("hca-pico")
    except Exception:
        pass
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        wlan.connect(cfg["ssid"], cfg.get("password", ""))
        for _ in range(150):
            if wlan.isconnected(): break
            time.sleep_ms(100)

    led = None
    try:
        led = machine.Pin("LED", machine.Pin.OUT); led.value(1 if wlan.isconnected() else 0)
    except Exception:
        pass

    if not wlan.isconnected():
        # USB floppy stays available even if WiFi credentials are temporarily wrong.
        while True:
            time.sleep(1)

    ip = wlan.ifconfig()[0]
    print("HCA_PICO_IP=" + ip)
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", 80)); srv.listen(2); srv.settimeout(0.2)

    # Keep the network bridge alive even if custom USB MSC cannot start.
    usb_error = ""
    try:
        if not msc.active:
            msc.start()
    except Exception as e:
        usb_error = str(e)
        print("HCA_USB_MSC_ERROR", usb_error)

    while True:
        try:
            cl, addr = srv.accept()
        except OSError:
            time.sleep_ms(10); continue
        try:
            cl.settimeout(8)
            req = _read_request(cl)
            if not req:
                _send_http(cl, 400, _json_bytes({"ok": False, "error": "Bad request"})); continue
            method, target, headers, initial = req
            if method == "OPTIONS":
                _send_http(cl, 204, b""); continue
            path, _, query = target.partition("?")
            if method == "GET" and path == "/api/status":
                info = disk.info(); info.update({
                    "ok": True, "bridge_version": BRIDGE_VERSION, "layout": "USB-Floppy-1.40i/SFR1M44",
                    "wifi_ip": ip, "usb_msc": "ready" if msc.active else "error",
                    "usb_error": usb_error
                })
                _send_http(cl, 200, _json_bytes(info))
            elif method == "POST" and path == "/api/pattern":
                name = "PATTERN.TAP"
                for pair in query.split("&"):
                    if pair.startswith("name="):
                        name = _percent_decode(pair[5:]) or name
                name = name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
                _save_pattern(cl, headers, initial, name, msc, disk)
            else:
                _send_http(cl, 404, _json_bytes({"ok": False, "error": "Not found"}))
        except Exception as e:
            try: _send_http(cl, 500, _json_bytes({"ok": False, "error": str(e)}))
            except Exception: pass
        finally:
            try: cl.close()
            except Exception: pass
            gc.collect()
