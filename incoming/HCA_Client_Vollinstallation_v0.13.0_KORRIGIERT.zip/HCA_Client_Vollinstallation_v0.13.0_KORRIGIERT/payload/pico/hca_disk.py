# HCA Pico 2 W - virtual USB Floppy Emulator 1.40i disk layout
# Synthesizes the raw multi-floppy layout observed on the user's working SFR USB stick.
import struct
try:
    import ubinascii as binascii
except ImportError:
    import binascii

SECTOR_SIZE = 512
SLOT_SECTORS = 3072          # 0x180000 bytes per virtual floppy slot
FLOPPY_SECTORS = 2880        # standard 1.44 MB FAT12 floppy
SLOT_COUNT = 100             # FLPPY0..FLPPY99
TOTAL_SECTORS = 498015       # exact sector count of analyzed USB stick
DATA_FIRST_SECTOR = 33       # FAT12: boot + 2xFAT + root
DATA_LAST_F6_SECTOR = 2878   # analyzer reference: sector 2879 is zero
MAX_PATTERN_BYTES = 1400000

_BOOT_B64 = (
    "6zyQTVNET1M1LjAAAgEBAALgAEAL8AkAEgACAAAAAAAAAAAAAAAph3d1WUZMUFBZMCAgICAgRkFUMTIgICAzyY7RvPx7Fge9eADFdgAeVhZVvyIFiX4AiU4CsQv886QGH70AfMZF/g84TiR9IIvBmeh+AYPrOmahHHxmOweKV/x1BoDKAohWAoDDEHPtM8n+Bth9ikYQmPdmFgNGHBNWHgNGDhPRi3YRYIlG/IlW/rggAPfmi14LA8NI9/MBRvwRTv5hvwAH6CgBcj44LXQXYLELvth986ZhdD1OdAmDxyA7+3Ln693+Dth9e6e+f32smAPwrJhAdAxIdBO0DrsHAM0Q6+++gn3r5r6AfevhzRZeH2aPBM0ZvoF9i30ajUX+ik4N9+EDRvwTVv6xBOjCAHLX6gACcABSUAZTagFqEJGLRhiiJgWWkjPS9/aR9/ZCh8r3dhqK8orowMwCCsy4AQKAfgIOdQS0Qov0ilYkzRNhYXIKQHUBQgNeC0l1d8MDGAEnDQpJbnZhbGlkIHN5c3RlbSBkaXNr/w0KRGlzayBJL08gZXJyb3L/DQpSZXBsYWNlIHRoZSBkaXNrLCBhbmQgdGhlbiBwcmVzcyBhbnkga2V5DQoAAElPICAgICAgU1lTTVNET1MgICBTWVN/AQBBuwAHYGZqAOk7/wAAVao="
)
_BOOT_TEMPLATE = binascii.a2b_base64(_BOOT_B64)
_ZERO_SECTOR = b"\x00" * SECTOR_SIZE
_F6_SECTOR = b"\xF6" * SECTOR_SIZE


def _fill(buf, value=0):
    # MicroPython-friendly fill without allocating another 512-byte object each call.
    if value == 0 and len(buf) == SECTOR_SIZE:
        buf[:] = _ZERO_SECTOR
    elif value == 0xF6 and len(buf) == SECTOR_SIZE:
        buf[:] = _F6_SECTOR
    elif value == 0:
        buf[:] = b"\x00" * len(buf)
    elif value == 0xF6:
        buf[:] = b"\xF6" * len(buf)
    else:
        for i in range(len(buf)):
            buf[i] = value


def _pad_text_right(value, width):
    # MicroPython v1.29 on RP2350 does not provide str.ljust()/bytes.ljust().
    value = value[:width]
    if len(value) < width:
        value += " " * (width - len(value))
    return value


def _slot_label(slot):
    return _pad_text_right("FLPPY%d" % slot, 11).encode("ascii")


def _short_name(filename):
    name = str(filename or "PATTERN.TAP").replace("\\", "/").split("/")[-1]
    if "." in name:
        stem, ext = name.rsplit(".", 1)
    else:
        stem, ext = name, "TAP"
    allowed = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$%'-@~`!(){}^#&"
    def clean(s):
        s = s.upper()
        return "".join(ch if ch in allowed else "_" for ch in s)
    stem, ext = clean(stem), clean(ext)
    if not stem:
        stem = "PATTERN"
    if len(stem) > 8:
        stem = stem[:6] + "~1"
    stem = _pad_text_right(stem, 8)
    ext = _pad_text_right(ext or "TAP", 3)
    return (stem + ext).encode("ascii")


def _fat12_set(fat, cluster, value):
    pos = cluster + cluster // 2
    value &= 0xFFF
    if cluster & 1:
        fat[pos] = (fat[pos] & 0x0F) | ((value << 4) & 0xF0)
        fat[pos + 1] = (value >> 4) & 0xFF
    else:
        fat[pos] = value & 0xFF
        fat[pos + 1] = (fat[pos + 1] & 0xF0) | ((value >> 8) & 0x0F)


class HcaFloppyDisk:
    def __init__(self, pattern_path="pattern.bin", meta_path="pattern.meta"):
        self.pattern_path = pattern_path
        self.meta_path = meta_path
        self.pattern_name = ""
        self.pattern_size = 0
        self.short_name = _short_name("PATTERN.TAP")
        self._fat = bytearray(9 * SECTOR_SIZE)
        self._empty_fat = bytearray(9 * SECTOR_SIZE)
        self._empty_fat[0:3] = b"\xF0\xFF\xFF"
        self._fp = None
        self.reload()

    def _close_pattern(self):
        try:
            if self._fp:
                self._fp.close()
        except Exception:
            pass
        self._fp = None

    def reload(self):
        self._close_pattern()
        self.pattern_name = ""
        self.pattern_size = 0
        try:
            with open(self.meta_path, "r") as f:
                raw = f.read().strip().split("\t")
                if len(raw) >= 2:
                    self.pattern_name = raw[0]
                    self.pattern_size = int(raw[1])
        except Exception:
            pass
        try:
            if self.pattern_size > 0:
                self._fp = open(self.pattern_path, "rb")
        except Exception:
            self.pattern_size = 0
            self.pattern_name = ""
            self._fp = None
        if self.pattern_size > MAX_PATTERN_BYTES:
            self.pattern_size = 0
            self.pattern_name = ""
            self._close_pattern()
        self.short_name = _short_name(self.pattern_name or "PATTERN.TAP")
        self._build_fat()

    def _build_fat(self):
        self._fat[:] = b"\x00" * len(self._fat)
        self._fat[0:3] = b"\xF0\xFF\xFF"
        if self.pattern_size <= 0:
            return
        clusters = (self.pattern_size + SECTOR_SIZE - 1) // SECTOR_SIZE
        # Clusters 2.. are one sector each on a 1.44MB FAT12 floppy.
        for i in range(clusters):
            c = 2 + i
            _fat12_set(self._fat, c, 0xFFF if i == clusters - 1 else c + 1)

    def _boot_sector(self, slot, buf):
        buf[:] = _BOOT_TEMPLATE
        # Deterministic volume serial; format/position matches the captured image.
        serial = (0x59757787 + slot * 0x101) & 0xFFFFFFFF
        struct.pack_into("<I", buf, 39, serial)
        buf[43:54] = _slot_label(slot)

    def _root_sector(self, slot, rel, buf):
        _fill(buf, 0)
        if rel != 19:
            return
        # Volume label entry.
        buf[0:11] = _slot_label(slot)
        buf[11] = 0x08
        # Slot 0 contains the currently uploaded embroidery file.
        if slot == 0 and self.pattern_size > 0:
            off = 32
            buf[off:off + 11] = self.short_name
            buf[off + 11] = 0x20
            struct.pack_into("<H", buf, off + 26, 2)
            struct.pack_into("<I", buf, off + 28, self.pattern_size)

    def _meta_sector(self, buf):
        _fill(buf, 0)
        stamp = b"UPDATE TIME:2026-09-08 00-00-00"
        buf[:len(stamp)] = stamp
        text = b"MAX BLOCK:100"
        buf[0x50:0x50 + len(text)] = text

    def _pattern_sector(self, file_sector, buf):
        # 1.40i leaves the slack bytes in the file's final cluster at 0x00.
        _fill(buf, 0)
        if not self._fp or file_sector < 0:
            return
        start = file_sector * SECTOR_SIZE
        if start >= self.pattern_size:
            return
        try:
            self._fp.seek(start)
            remaining = self.pattern_size - start
            count = SECTOR_SIZE if remaining >= SECTOR_SIZE else remaining
            # Read only the actual file bytes, leave the rest at format fill value 0xF6.
            try:
                n = self._fp.readinto(memoryview(buf)[:count])
                if n is None:
                    n = 0
            except AttributeError:
                data = self._fp.read(count)
                n = len(data)
                buf[:n] = data
        except Exception:
            pass

    def read_sector(self, lba, buf):
        if len(buf) < SECTOR_SIZE:
            raise ValueError("buffer too small")
        _fill(buf, 0)
        if lba < 0 or lba >= TOTAL_SECTORS:
            return buf
        used = SLOT_COUNT * SLOT_SECTORS
        if lba >= used:
            return buf
        slot = lba // SLOT_SECTORS
        rel = lba - slot * SLOT_SECTORS
        if rel == 0:
            self._boot_sector(slot, buf)
        elif 1 <= rel <= 9:
            fat = self._fat if slot == 0 else self._empty_fat
            off = (rel - 1) * SECTOR_SIZE
            buf[:] = fat[off:off + SECTOR_SIZE]
        elif 10 <= rel <= 18:
            fat = self._fat if slot == 0 else self._empty_fat
            off = (rel - 10) * SECTOR_SIZE
            buf[:] = fat[off:off + SECTOR_SIZE]
        elif 19 <= rel <= 32:
            self._root_sector(slot, rel, buf)
        elif DATA_FIRST_SECTOR <= rel <= DATA_LAST_F6_SECTOR:
            if slot == 0 and self.pattern_size > 0:
                file_sector = rel - DATA_FIRST_SECTOR
                file_sectors = (self.pattern_size + SECTOR_SIZE - 1) // SECTOR_SIZE
                if file_sector < file_sectors:
                    self._pattern_sector(file_sector, buf)
                else:
                    _fill(buf, 0xF6)
            else:
                _fill(buf, 0xF6)
        elif rel == SLOT_SECTORS - 1:
            self._meta_sector(buf)
        # rel 2879 and padding 2880..3070 stay zero, matching the analyzed reference.
        return buf

    def info(self):
        return {
            "pattern_name": self.pattern_name,
            "pattern_size": self.pattern_size,
            "short_name": self.short_name.decode("ascii").strip(),
            "slot": 0,
            "slots": SLOT_COUNT,
            "total_sectors": TOTAL_SECTORS,
        }

    def close(self):
        self._close_pattern()
