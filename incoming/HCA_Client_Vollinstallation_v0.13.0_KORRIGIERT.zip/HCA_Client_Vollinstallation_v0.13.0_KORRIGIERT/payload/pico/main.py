import hca_bridge
hca_bridge.run()
