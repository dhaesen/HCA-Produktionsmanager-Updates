# Prepare the virtual floppy. USB MSC starts later in main.py, after WiFi/HTTP.
try:
    import hca_bridge
    hca_bridge.boot_usb()
except Exception as e:
    print("HCA_BOOT_PREP_ERROR", e)
