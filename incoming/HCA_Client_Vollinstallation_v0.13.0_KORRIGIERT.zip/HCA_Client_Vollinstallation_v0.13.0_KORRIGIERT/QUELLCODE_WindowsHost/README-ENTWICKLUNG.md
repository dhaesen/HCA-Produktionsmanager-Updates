# HCA Windows-Host v0.12.1

Dieser Host ersetzt den sichtbaren Edge-/Chrome-App-Modus durch ein eigenes
WPF-Fenster mit Microsoft WebView2. Die bestehende Go-EXE bleibt als unsichtbarer
lokaler Dienst erhalten, weil sie Drucker, COM-Ports, Dateien, Pico und Updates
bereitstellt.

## Voraussetzungen zum Bauen

- .NET SDK 8 oder neuer
- Internetzugriff auf NuGet beim ersten Build
- Windows-Zielplattform x64

## Build

```powershell
dotnet restore .\HcaWindowsHost.csproj
dotnet build .\HcaWindowsHost.csproj -c Release
```

Der Host zielt bewusst auf .NET Framework 4.8, damit auf üblichen Windows-10-
und Windows-11-Rechnern kein separates modernes .NET-Desktop-Runtime-Paket
installiert werden muss. Die WebView2-DLLs und der x64-WebView2Loader müssen
neben der erzeugten EXE liegen.

## Backend ohne Browserstart

`Patch-Backend.ps1` darf ausschließlich auf die exakt geprüfte v0.10.3-EXE mit
dem im Skript hinterlegten SHA-256 angewendet werden. Es ersetzt am Einstieg von
`main.openApp` genau ein Byte durch `RET`. Dadurch bleiben HTTP-Dienst, Drucker,
COM, Pico und Updates unverändert erhalten, während Edge/Chrome nicht mehr
automatisch gestartet wird.

Bei jeder neuen Backend-Version muss diese Stelle neu aus dem Quellcode gebaut
oder neu geprüft werden. Den Byte-Patch niemals ungeprüft auf eine andere EXE
anwenden.
