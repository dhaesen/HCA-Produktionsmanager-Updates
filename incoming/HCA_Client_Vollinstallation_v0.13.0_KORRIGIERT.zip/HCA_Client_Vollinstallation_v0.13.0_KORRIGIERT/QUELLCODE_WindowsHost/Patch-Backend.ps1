param(
    [Parameter(Mandatory = $true)] [string] $InputExe,
    [Parameter(Mandatory = $true)] [string] $OutputExe
)

$ErrorActionPreference = 'Stop'
$expectedHash = 'd4e7d6bc2ed7a75ccd821b7913616b8ad5e5f83a3cf42b0253103381a9a1e56f'
$patchOffset = 0x2FAD20
$expectedByte = 0x4C
$replacementByte = 0xC3

$actualHash = (Get-FileHash -Algorithm SHA256 -Path $InputExe).Hash.ToLowerInvariant()
if ($actualHash -ne $expectedHash) {
    throw "Unbekannte Backend-Version. Erwartet: $expectedHash, erhalten: $actualHash"
}

$bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $InputExe))
if ($bytes.Length -le $patchOffset -or $bytes[$patchOffset] -ne $expectedByte) {
    throw 'Die geprüfte Browserstart-Stelle wurde nicht gefunden. Datei bleibt unverändert.'
}

$bytes[$patchOffset] = $replacementByte
[System.IO.File]::WriteAllBytes($OutputExe, $bytes)
Write-Host "Backend ohne Browserstart erzeugt: $OutputExe" -ForegroundColor Green
