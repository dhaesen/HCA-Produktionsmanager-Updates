$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $root
try {
    dotnet restore .\HcaWindowsHost.csproj
    dotnet build .\HcaWindowsHost.csproj -c Release --no-restore
    Write-Host 'Build erfolgreich: bin\Release\net48' -ForegroundColor Green
} finally {
    Pop-Location
}
