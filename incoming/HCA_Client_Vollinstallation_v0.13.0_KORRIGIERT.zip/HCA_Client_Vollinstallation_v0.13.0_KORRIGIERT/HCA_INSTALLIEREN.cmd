@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo.
echo HCA Produktionsmanager v0.13.0 - korrigierte Installation
echo ================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLIEREN.ps1"
if errorlevel 1 (
  echo.
  echo Die Installation konnte nicht abgeschlossen werden.
  echo Bitte sende die oben angezeigte Fehlermeldung.
  echo.
  pause
  exit /b 1
)
echo.
echo Fertig.
timeout /t 3 /nobreak >nul
