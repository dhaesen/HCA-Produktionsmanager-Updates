@echo off
chcp 65001 >nul
setlocal
set "HCA_EXE=%LOCALAPPDATA%\Programs\HCA Produktionsmanager\HCA_Produktionsmanager.exe"
set "HCA_LOG=%LOCALAPPDATA%\HCA Produktionsmanager\hca-start.log"

if not exist "%HCA_EXE%" (
  echo HCA ist nicht am erwarteten Ort installiert:
  echo %HCA_EXE%
  pause
  exit /b 1
)

start "" "%HCA_EXE%"
timeout /t 6 /nobreak >nul

if exist "%HCA_LOG%" (
  start "" notepad.exe "%HCA_LOG%"
) else (
  echo Es wurde noch kein Startprotokoll erzeugt.
  echo Falls auch keine Windows-Fehlermeldung erscheint, wurde die EXE vermutlich
  echo durch Sicherheitssoftware blockiert oder entfernt.
  pause
)
