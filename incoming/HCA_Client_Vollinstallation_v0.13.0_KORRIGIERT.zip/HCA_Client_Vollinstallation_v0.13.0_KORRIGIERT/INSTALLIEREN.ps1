$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'HCA Produktionsmanager - Installation'

function Write-Step([string]$Text) {
    Write-Host "`n==> $Text" -ForegroundColor Cyan
}

$setupRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $setupRoot 'payload'
$target = Join-Path $env:LOCALAPPDATA 'Programs\HCA Produktionsmanager'

Write-Host 'HCA Produktionsmanager v0.13.0 - korrigierte Vollinstallation' -ForegroundColor White
Write-Host 'Die Installation erfolgt nur für den aktuellen Windows-Benutzer und benötigt keine Administratorrechte.'

if (-not (Test-Path (Join-Path $payload 'HCA_Produktionsmanager.exe'))) {
    throw 'Installationsdateien unvollständig: HCA_Produktionsmanager.exe fehlt.'
}

Write-Step 'Installationspaket prüfen'
$hashFile = Join-Path $payload 'SHA256SUMS.txt'
if (Test-Path $hashFile) {
    $bad = @()
    Get-Content $hashFile | ForEach-Object {
        if ($_ -match '^([0-9a-fA-F]{64})\s+\*?(.+)$') {
            $expected = $matches[1].ToLowerInvariant()
            $rel = $matches[2] -replace '^\.\\','' -replace '^\./',''
            $file = Join-Path $payload ($rel -replace '/', '\')
            if (-not (Test-Path $file)) {
                $bad += "$rel (fehlt)"
            } else {
                $actual = (Get-FileHash -Algorithm SHA256 -Path $file).Hash.ToLowerInvariant()
                if ($actual -ne $expected) { $bad += "$rel (Prüfsumme falsch)" }
            }
        }
    }
    if ($bad.Count -gt 0) {
        throw ('Paketprüfung fehlgeschlagen: ' + ($bad -join ', '))
    }
    Write-Host 'Paketprüfung OK.' -ForegroundColor Green
}

Write-Step 'Laufenden HCA Client beenden'
Get-Process -Name 'HCA_Produktionsmanager' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process -Name 'HCA_Backend' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500

# Try to find an existing installation so local settings can be retained.
$oldCandidates = @(
    $target,
    'C:\HCA-Produktionsmanager',
    'C:\HCA Produktionsmanager',
    (Join-Path $env:USERPROFILE 'HCA-Produktionsmanager'),
    (Join-Path $env:USERPROFILE 'Desktop\HCA-Produktionsmanager')
) | Select-Object -Unique

$oldInstall = $null
foreach ($candidate in $oldCandidates) {
    if ((Test-Path (Join-Path $candidate 'config.json')) -or (Test-Path (Join-Path $candidate 'data'))) {
        $oldInstall = $candidate
        break
    }
}

$preserveRoot = Join-Path $env:TEMP ('HCA-preserve-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $preserveRoot | Out-Null

if ($oldInstall) {
    Write-Host "Bestehende lokale Einstellungen gefunden: $oldInstall" -ForegroundColor Yellow
    if (Test-Path (Join-Path $oldInstall 'config.json')) {
        Copy-Item (Join-Path $oldInstall 'config.json') (Join-Path $preserveRoot 'config.json') -Force
    }
    if (Test-Path (Join-Path $oldInstall 'data')) {
        Copy-Item (Join-Path $oldInstall 'data') (Join-Path $preserveRoot 'data') -Recurse -Force
    }
}

Write-Step 'HCA installieren'
New-Item -ItemType Directory -Force -Path $target | Out-Null

# Replace only program/support files. Existing config.json and data are handled separately.
Get-ChildItem -Path $payload -Force | ForEach-Object {
    if ($_.Name -notin @('config.default.json','data')) {
        $dest = Join-Path $target $_.Name
        if ($_.PSIsContainer) {
            if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
            Copy-Item $_.FullName $dest -Recurse -Force
        } else {
            Copy-Item $_.FullName $dest -Force
        }
    }
}

# Restore settings/data from an existing installation if found.
if (Test-Path (Join-Path $preserveRoot 'config.json')) {
    Copy-Item (Join-Path $preserveRoot 'config.json') (Join-Path $target 'config.json') -Force
} elseif (-not (Test-Path (Join-Path $target 'config.json'))) {
    Copy-Item (Join-Path $payload 'config.default.json') (Join-Path $target 'config.json') -Force
}

if (Test-Path (Join-Path $preserveRoot 'data')) {
    if (Test-Path (Join-Path $target 'data')) { Remove-Item (Join-Path $target 'data') -Recurse -Force }
    Copy-Item (Join-Path $preserveRoot 'data') (Join-Path $target 'data') -Recurse -Force
} elseif (-not (Test-Path (Join-Path $target 'data'))) {
    Copy-Item (Join-Path $payload 'data') (Join-Path $target 'data') -Recurse -Force
}
Remove-Item $preserveRoot -Recurse -Force -ErrorAction SilentlyContinue

# Create shortcuts.
Write-Step 'Verknüpfungen anlegen'
$exe = Join-Path $target 'HCA_Produktionsmanager.exe'
$wsh = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
foreach ($shortcutPath in @(
    (Join-Path $desktop 'HCA Produktionsmanager.lnk'),
    (Join-Path $startMenu 'HCA Produktionsmanager.lnk')
)) {
    $sc = $wsh.CreateShortcut($shortcutPath)
    $sc.TargetPath = $exe
    $sc.WorkingDirectory = $target
    $sc.Description = 'HCA Produktionsmanager'
    $sc.IconLocation = "$exe,0"
    $sc.Save()
}

# Register a simple per-user app entry in Apps & Features.
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\HCA Produktionsmanager'
New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayName' -Value 'HCA Produktionsmanager' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayVersion' -Value '0.13.0' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'Publisher' -Value 'Werbestudio Königswinter' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'InstallLocation' -Value $target -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'DisplayIcon' -Value $exe -PropertyType String -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'NoModify' -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name 'NoRepair' -Value 1 -PropertyType DWord -Force | Out-Null

Write-Step 'Installation abgeschlossen'
Write-Host "Installiert nach: $target" -ForegroundColor Green
Write-Host 'Eine Desktop-Verknüpfung wurde erstellt.' -ForegroundColor Green
Write-Host 'Lokale Einstellungen und der data-Ordner wurden, soweit gefunden, übernommen.' -ForegroundColor Green
Write-Host ''
Write-Host 'HCA wird jetzt gestartet ...'
Start-Process -FilePath $exe -WorkingDirectory $target
Start-Sleep -Seconds 2
